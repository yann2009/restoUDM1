﻿/************************************************************************
	Filename 	 :	Common.cs
	Created  	 :	18/09/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	File containing common class methods to be used
                    within this application
*************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;


namespace restoPOS.Commons
{
    public static class Common
    {
        public static string CONNECTIONSTRING = Properties.Settings.Default.restoPOSConnectionString;
        
        /// <summary>
        /// Prevent a bug when showing a Microsoft tool tip</summary>
        /// <param name="tp">
        /// ToolTip object to be called</param>
        /// <param name="msg">
        /// Message to show</param>
        /// <param name="controlObj">
        /// Control where tool tip will appear</param>
        public static void ShowErrorToolTip(ToolTip tp, string msg, Control controlObj)
        {
            tp.Active = false;
            tp.Show("", controlObj);
            tp.Active = true;
            tp.Show(msg, controlObj);
        }

        /// <summary>
        /// Deletes the record as specified in the sqlQuery parameter</summary>
        /// <param name="msgContent">
        /// Message box content</param>
        /// <param name="msgTitle">
        /// Message box title</param>
        /// <param name="connectionString">
        /// The connection to the database</param>
        /// <param name="sqlQuery">
        /// Query to execute</param>
        /// <returns>
        /// True if operation is a success, else false</returns>
        public static bool DeleteRecord(string msgContent, string msgTitle, string sqlQuery, string connectionString = "default")
        {
            if (connectionString.Equals("default"))
                connectionString = CONNECTIONSTRING;

            DialogResult delResult = MessageBox.Show(msgContent, msgTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (delResult == DialogResult.Yes)
                if (DoSqlNonQuery(sqlQuery, connectionString) > 0)
                    return true;

            return false;
        }

        /// <summary>
        /// A generalized way of performing SQL non-queries</summary>
        /// <param name="connectionString">
        /// The connection to the database</param>
        /// <param name="sqlNonQuery">
        /// SQL non-query code</param>
        /// <returns>
        /// The number of row affected by the operation</returns>
        public static int DoSqlNonQuery(string sqlNonQuery, string connectionString = "default")
        {
            if (connectionString.Equals("default"))
                connectionString = CONNECTIONSTRING;

            int result = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(sqlNonQuery, conn))
            {
                conn.Open();
                result = cmd.ExecuteNonQuery();
                conn.Close();
            }

            return result;
        }

        /// <summary>
        /// A generalized way of performing SQL queries</summary>
        /// <param name="connectionString">
        /// The connection to the database</param>
        /// <param name="sqlQuery">
        /// SQL query code</param>
        /// <param name="cols">
        /// List of colons to retrieve data from</param>
        /// <returns>
        /// Hashtable containing the colons specified</returns>
        public static Hashtable DoSqlQuery(string sqlQuery, short[] cols, string connectionString = "default")
        {
            if (connectionString.Equals("default"))
                connectionString = CONNECTIONSTRING;

            Hashtable tblRecords = new Hashtable();
            
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = sqlQuery;

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                int iRow = 0;
                while (reader.Read())
                {
                    Hashtable objs = new Hashtable();
                    foreach (int iCol in cols)
                        objs[iCol] = reader.GetValue(iCol);

                    tblRecords[iRow++] = objs;
                }
                conn.Close();
            }

            return tblRecords;
        }

        /// <summary>
        /// Test a database table and look for the existence of data specified</summary>
        /// <param name="connectionString">
        /// Connection to database</param>
        /// <param name="tbl">
        /// Table to search</param>
        /// <param name="condi">
        /// Sets of condition to verify existence</param>
        /// <returns>
        /// Returns true if found, else false</returns>
        public static bool ValueExistInTable(string tbl, string condi, string connectionString = "default")
        {
            if (connectionString.Equals("default"))
                connectionString = CONNECTIONSTRING;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = "SELECT count(*) FROM " + tbl + " WHERE " + condi;

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                reader.Read();
                if ((int)(reader.GetValue(0)) > 0)
                    return true;

                conn.Close();
            }

            return false;
        }

        /// <summary>
        /// Quick validation for textboxes; Shows any error if present</summary>
        /// <param name="textbox">
        /// Textbox reference</param>
        /// <param name="tp">
        /// Reference to Tooltip</param>
        /// <param name="validateForEmptyField">
        /// Check for empty field</param>
        /// <param name="lim">
        /// Character limit</param>
        /// <returns>
        /// True if text is valid, else false</returns>
        public static bool TextBoxIsValid(TextBox textbox, ToolTip tp, bool validateForEmptyField, int lim)
        {
            tp.Active = false;
            tp.RemoveAll();

            if (textbox.Text.Equals("") && validateForEmptyField)
            {
                ShowErrorToolTip(tp, "Empty field", textbox);
                return false;
            }
            else if (textbox.Text.Length > lim)
            {
                ShowErrorToolTip(tp, "Text must be shorter than " + Convert.ToString(lim) + " characters", textbox);
                return false;
            }

            return true;
        }
    }
}
