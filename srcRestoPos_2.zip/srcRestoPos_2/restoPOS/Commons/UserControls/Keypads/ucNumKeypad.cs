﻿/************************************************************************
	Filename 	 :	unNumKeypad.cs
	Created  	 :	14/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	A simple numeric keypad control
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace restoPOS.Commons.UserControls.Keypads
{
    public partial class ucNumKeypad : UserControl
    {
        public delegate void NumKeypadKeyPressedHandler(string keyValue);
        public delegate void ClearKeyPressedHandler();
        public delegate void GoKeyPressedHandler();

        public event NumKeypadKeyPressedHandler NumKeypadKeyPressed;
        public event ClearKeyPressedHandler ClearKeyPressed;
        public event GoKeyPressedHandler GoKeyPressed;

        private bool m_GoButtonEnable;
        public bool GoButtonEnable
        {
            get { return m_GoButtonEnable; }
            set
            {
                m_GoButtonEnable = value;
                btn_GO.Enabled = m_GoButtonEnable;
            }
        }

        public ucNumKeypad()
        {
            InitializeComponent();
        }

        private void BTNs_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            NumKeypadKeyPressed(btn.Tag.ToString());
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            ClearKeyPressed();
        }

        private void btn_GO_Click(object sender, EventArgs e)
        {
            GoKeyPressed();
        }
    }
}
