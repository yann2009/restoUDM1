﻿namespace restoPOS.Commons.UserControls.Keypads
{
    partial class ucNumKeypad
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_GO = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.bnt_3 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_GO
            // 
            this.btn_GO.BackColor = System.Drawing.Color.White;
            this.btn_GO.FlatAppearance.BorderSize = 0;
            this.btn_GO.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn_GO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_GO.Image = global::restoPOS.Properties.Resources.enter2_48;
            this.btn_GO.Location = new System.Drawing.Point(131, 165);
            this.btn_GO.Name = "btn_GO";
            this.btn_GO.Size = new System.Drawing.Size(48, 48);
            this.btn_GO.TabIndex = 27;
            this.btn_GO.Tag = "GO";
            this.btn_GO.UseVisualStyleBackColor = false;
            this.btn_GO.Click += new System.EventHandler(this.btn_GO_Click);
            // 
            // btn_0
            // 
            this.btn_0.BackColor = System.Drawing.Color.White;
            this.btn_0.FlatAppearance.BorderSize = 0;
            this.btn_0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_0.Image = global::restoPOS.Properties.Resources._0_filled_48;
            this.btn_0.Location = new System.Drawing.Point(66, 165);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(48, 48);
            this.btn_0.TabIndex = 26;
            this.btn_0.Tag = "0";
            this.btn_0.UseVisualStyleBackColor = false;
            this.btn_0.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.Color.White;
            this.btn_Clear.FlatAppearance.BorderSize = 0;
            this.btn_Clear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.IndianRed;
            this.btn_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Clear.Image = global::restoPOS.Properties.Resources.delete_48;
            this.btn_Clear.Location = new System.Drawing.Point(3, 165);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(48, 48);
            this.btn_Clear.TabIndex = 25;
            this.btn_Clear.Tag = "CLEAR";
            this.btn_Clear.UseVisualStyleBackColor = false;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.Color.White;
            this.btn_9.FlatAppearance.BorderSize = 0;
            this.btn_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_9.Image = global::restoPOS.Properties.Resources._9_filled_48;
            this.btn_9.Location = new System.Drawing.Point(131, 111);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(48, 48);
            this.btn_9.TabIndex = 24;
            this.btn_9.Tag = "9";
            this.btn_9.UseVisualStyleBackColor = false;
            this.btn_9.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.Color.White;
            this.btn_8.FlatAppearance.BorderSize = 0;
            this.btn_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_8.Image = global::restoPOS.Properties.Resources._8_filled_48;
            this.btn_8.Location = new System.Drawing.Point(66, 111);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(48, 48);
            this.btn_8.TabIndex = 23;
            this.btn_8.Tag = "8";
            this.btn_8.UseVisualStyleBackColor = false;
            this.btn_8.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.Color.White;
            this.btn_7.FlatAppearance.BorderSize = 0;
            this.btn_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_7.Image = global::restoPOS.Properties.Resources._7_filled_48;
            this.btn_7.Location = new System.Drawing.Point(3, 111);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(48, 48);
            this.btn_7.TabIndex = 22;
            this.btn_7.Tag = "7";
            this.btn_7.UseVisualStyleBackColor = false;
            this.btn_7.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.Color.White;
            this.btn_6.FlatAppearance.BorderSize = 0;
            this.btn_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_6.Image = global::restoPOS.Properties.Resources._6_filled_48;
            this.btn_6.Location = new System.Drawing.Point(131, 57);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(48, 48);
            this.btn_6.TabIndex = 21;
            this.btn_6.Tag = "6";
            this.btn_6.UseVisualStyleBackColor = false;
            this.btn_6.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.Color.White;
            this.btn_5.FlatAppearance.BorderSize = 0;
            this.btn_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_5.Image = global::restoPOS.Properties.Resources._5_filled_48;
            this.btn_5.Location = new System.Drawing.Point(66, 57);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(48, 48);
            this.btn_5.TabIndex = 20;
            this.btn_5.Tag = "5";
            this.btn_5.UseVisualStyleBackColor = false;
            this.btn_5.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.Color.White;
            this.btn_4.FlatAppearance.BorderSize = 0;
            this.btn_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_4.Image = global::restoPOS.Properties.Resources._4_filled_48;
            this.btn_4.Location = new System.Drawing.Point(3, 57);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(48, 48);
            this.btn_4.TabIndex = 19;
            this.btn_4.Tag = "4";
            this.btn_4.UseVisualStyleBackColor = false;
            this.btn_4.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // bnt_3
            // 
            this.bnt_3.BackColor = System.Drawing.Color.White;
            this.bnt_3.FlatAppearance.BorderSize = 0;
            this.bnt_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bnt_3.Image = global::restoPOS.Properties.Resources._3_filled_48;
            this.bnt_3.Location = new System.Drawing.Point(131, 3);
            this.bnt_3.Name = "bnt_3";
            this.bnt_3.Size = new System.Drawing.Size(48, 48);
            this.bnt_3.TabIndex = 18;
            this.bnt_3.Tag = "3";
            this.bnt_3.UseVisualStyleBackColor = false;
            this.bnt_3.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.Color.White;
            this.btn_2.FlatAppearance.BorderSize = 0;
            this.btn_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_2.Image = global::restoPOS.Properties.Resources._2_filled_48;
            this.btn_2.Location = new System.Drawing.Point(66, 3);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(48, 48);
            this.btn_2.TabIndex = 17;
            this.btn_2.Tag = "2";
            this.btn_2.UseVisualStyleBackColor = false;
            this.btn_2.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.Color.White;
            this.btn_1.FlatAppearance.BorderSize = 0;
            this.btn_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_1.Image = global::restoPOS.Properties.Resources._1_filled_48;
            this.btn_1.Location = new System.Drawing.Point(3, 3);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(48, 48);
            this.btn_1.TabIndex = 16;
            this.btn_1.Tag = "1";
            this.btn_1.UseVisualStyleBackColor = false;
            this.btn_1.Click += new System.EventHandler(this.BTNs_Click);
            // 
            // ucNumKeypad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btn_GO);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.bnt_3);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucNumKeypad";
            this.Size = new System.Drawing.Size(186, 227);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_GO;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button bnt_3;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_1;
    }
}
