﻿/************************************************************************
	Filename 	 :	Animation.cs
	Created  	 :	17/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	File containing common class methods to be used within
                    this application
*************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;
using System.Timers;
using System.Threading;


namespace restoPOS.Commons
{
    public static class Animation
    {
        /// <summary>
        /// Animate form opening in a fade-in style</summary>
        /// <param name="frm">
        /// Host form for animation</param>
        /// <param name="opacityThrs">
        /// Final opacity the form will be after the animation. Value between 0-100</param>
        /// <param name="rate">
        /// Rate at which the animation is done</param>
        /// <param name="delay">
        /// Rate of the animation</param>
        public static void FadeIn(Form frm, int opacityThrs = 90, int rate = 1, int delay = 1)
        {
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = delay;

            int iOpa = 0;
            timer.Tick += new EventHandler((object source, EventArgs e) =>
            {
                if (iOpa <= opacityThrs)
                    frm.Opacity = ((double)iOpa) / 100.0;
                else
                    timer.Stop();

                iOpa += rate;
            });
            timer.Start();
        }

        /// <summary>
        /// Animate form opening in a fade-out style</summary>
        /// <param name="frm">
        /// Host form for animation</param>
        /// <param name="rate">
        /// Rate at which the animation is done</param>
        /// <param name="delay">
        /// Rate of the animation</param>
        public static void FadeOut(Form frm, int rate = 1, int delay = 1)
        {
            int actualOpacity = (int)(frm.Opacity * 100.0);

            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = delay;

            int iOpa = actualOpacity;
            timer.Tick += new EventHandler((object source, EventArgs e) =>
            {
                if (iOpa >= 0)
                    frm.Opacity = ((double)iOpa) / 100.0;
                else
                {
                    frm.Hide();
                    timer.Stop();
                }

                iOpa -= rate;
            });
            timer.Start();
        }

        /// <summary>
        /// Hide animation of a control</summary>
        /// <param name="ctrl">
        /// Control that will undergo the animation</param>
        /// <param name="ctrlProperText">
        /// Property of the control that will be change</param>
        /// <param name="limit">
        /// Defines the limit of the number of times a unit animation is done</param>
        /// <param name="controlProperty">
        /// The property of the control that will be used for animation</param>
        /// <param name="isControlHidden">
        /// Defines the 'visibility' of the control for the animation</param>
        /// <param name="rate">
        /// The value at each iteration (till <c>limit</c>) by which the control property will be incremented</param>
        /// <param name="delay">
        /// Rate at which the animation is done</param>
        public static void AnimationHide(Control ctrl, string ctrlProperText, int limit, ref bool isControlHidden, int rate = 1, int delay = 1)
        {
            if (!isControlHidden)
                AnimationToggle(ctrl, ctrlProperText, limit, ref isControlHidden, rate, delay);
        }

        /// <summary>
        /// Show animation of a control</summary>
        /// <param name="ctrl">
        /// Control that will undergo the animation</param>
        /// <param name="ctrlProperText">
        /// Property of the control that will be change</param>
        /// <param name="limit">
        /// Defines the limit of the number of times a unit animation is done</param>
        /// <param name="controlProperty">
        /// The property of the control that will be used for animation</param>
        /// <param name="isControlHidden">
        /// Defines the 'visibility' of the control for the animation</param>
        /// <param name="rate">
        /// The value at each iteration (till <c>limit</c>) by which the control property will be incremented</param>
        /// <param name="delay">
        /// Rate at which the animation is done</param>
        public static void AnimationShow(Control ctrl, string ctrlProperText, int limit, ref bool isControlHidden, int rate = 1, int delay = 1)
        {
            if (isControlHidden)
                AnimationToggle(ctrl, ctrlProperText, limit, ref isControlHidden, rate, delay);
        }

        /// <summary>
        /// Toggles (show/hide) animation of a control</summary>
        /// <param name="ctrl">
        /// Control that will undergo the animation</param>
        /// <param name="ctrlProperText">
        /// Property of the control that will be change. Ex: "Top", "Height"</param>
        /// <param name="limit">
        /// Defines the distance (limit) that the control will move</param>
        /// <param name="isControlHidden">
        /// Defines the 'visibility' of the control for the animation</param>
        /// <param name="rate">
        /// The value at each iteration (till <c>limit</c>) by which the control property will be incremented</param>
        /// <param name="delay">
        /// Rate at which the animation is done</param>
        public static void AnimationToggle(Control ctrl, string ctrlProperText, int limit, ref bool isControlHidden, int rate = 1, int delay = 1)
        {
            if (!isControlHidden)
                rate *= -1;

            if (delay > 0)
            {
                System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
                timer.Interval = delay;

                int i = 1;
                timer.Tick += new EventHandler((object source, EventArgs e) =>
                {
                    if (i <= limit)
                    {
                        int prop = (int)ctrl.GetType().GetProperty(ctrlProperText).GetValue(ctrl);
                        ctrl.GetType().GetProperty(ctrlProperText).SetValue(ctrl, (int)(prop + rate));
                    }
                    else
                        timer.Stop();

                    i += Math.Abs(rate);
                });
                timer.Start();
            }
            else
            {
                for (int i = 1; i <= limit; i += Math.Abs(rate))
                {
                    int prop = (int)ctrl.GetType().GetProperty(ctrlProperText).GetValue(ctrl);
                    ctrl.GetType().GetProperty(ctrlProperText).SetValue(ctrl, (int)(prop + rate));
                }
            }

            isControlHidden = !isControlHidden;
        }
    }
}
