﻿/************************************************************************
	Filename 	 :	Entities.cs
	Created  	 :	24/09/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	File containing common entity class to be used within
                    this application
 
                            --(NEEDS REVISION)--
*************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace restoPOS.Commons
{
    public static class Entities
    {
        public class Client
        {
            public string ID { get; set; }
            public string IdentityNumber { get; set; }
            public string FName { get; set; }
            public string LName { get; set; }
            public string Title { get; set; }
            public string Road { get; set; }
            public string Town { get; set; }
            public string District { get; set; }
            public string HomeNumber { get; set; }
            public string MobileNumber { get; set; }
            public DateTime DOB { get; set; }

            public override string ToString()
            {
                return LName + " " + FName;
            }
        }

        public enum TableStatus
        {
            Vacant,
            Occupied,
            Pending
        };
    }
}
