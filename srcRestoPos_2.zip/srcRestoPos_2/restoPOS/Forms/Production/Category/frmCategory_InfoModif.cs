﻿/************************************************************************
	Filename 	 :	frmCategory_InfoModif.cs
	Created  	 :	28/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Form to view, update and modify categories
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;

namespace restoPOS.Forms.Production.Category
{
    public partial class frmCategory_InfoModif : Form
    {
        private string ori_categoryLabel; // Initial category label to view

        private bool dataUpdated = false;
        private frmCategory parentForm;

        public frmCategory_InfoModif(string categoryID, frmCategory frmParent)
        {
            InitializeComponent();
            UpdateInformation(categoryID);

            parentForm = frmParent;
        }

        /// <summary>
        /// Updates the category fields and product field of the form</summary>
        /// <param name="categoryID">
        /// The ID of the category</param>
        private void UpdateInformation(string categoryID)
        {
            try
            {
                // Updates the fields
                Hashtable categoryLabels = Common.DoSqlQuery("SELECT Category_ID, Category_Label, Category_Tag, Category_Description " +
                                           "FROM Category WHERE Category_ID = " + categoryID, new short[] { 0, 1, 2, 3 });

                lblInfo_ID.Text = Convert.ToString(((Hashtable)categoryLabels[0])[0]);
                tbInfo_Label.Text = Convert.ToString(((Hashtable)categoryLabels[0])[1]);
                tbInfo_Tag.Text = Convert.ToString(((Hashtable)categoryLabels[0])[2]);
                tbInfo_Desc.Text = Convert.ToString(((Hashtable)categoryLabels[0])[3]);

                ori_categoryLabel = Convert.ToString(((Hashtable)categoryLabels[0])[1]);

                //Update list of products
                flpProductCategorizer.Controls.Clear();
                Hashtable productLabels = Common.DoSqlQuery("SELECT Product_ID, Product_Label FROM Product WHERE Product_Category = " + categoryID, new short[] { 0, 1 });
                int controlIndex = 0;
                foreach (DictionaryEntry row in productLabels)
                {
                    Button controlButton = new Button();
                    controlButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
                    controlButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                    controlButton.Name = "flpControl" + controlIndex++;
                    controlButton.Size = new System.Drawing.Size(228, 23);
                    controlButton.Tag = Convert.ToString(((Hashtable)row.Value)[0]);   // Product_ID
                    controlButton.Text = Convert.ToString(((Hashtable)row.Value)[1]);   // Product_Label
                    controlButton.Click += new EventHandler(flpProductCategorizerControl_Click);

                    flpProductCategorizer.Controls.Add(controlButton);
                }

                if (flpProductCategorizer.Controls.Count == 0)
                    lblNoProduct.Visible = true;
                else
                    lblNoProduct.Visible = false;
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Handles the click event of UpdateInformations' controls</summary>
        private void flpProductCategorizerControl_Click(object sender, EventArgs e)
        {
            Product.frmProduct ProductForm = new Product.frmProduct();
            ProductForm.Show();

            ProductForm.SelectCategoryItem(tbInfo_Label.Text);
            ProductForm.SelectProductItem(((Button)sender).Text);
        }

        private void btnUpdate_Cancel_Click(object sender, EventArgs e)
        {
            btnUpdateModify.Text = "Modify";
            btnUpdateModify.Tag = "0";
            btnUpdate_Cancel.Visible = false;

            tbInfo_Label.ReadOnly = true;
            tbInfo_Tag.ReadOnly = true;
            tbInfo_Desc.ReadOnly = true;

            UpdateInformation(lblInfo_ID.Text);

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();
        }

        private void TBs_TextChanged(object sender, EventArgs e)
        {
            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            TextBox textbox = (TextBox)sender;

            if (textbox.Name.Equals("tbNew_Label"))
                Common.TextBoxIsValid(tbInfo_Label, generalErrorToolTip, true, 30);
            if (textbox.Name.Equals("tbNew_Tag"))
                Common.TextBoxIsValid(tbInfo_Tag, generalErrorToolTip, false, 30);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if(dataUpdated)
                parentForm.PopulateCategories();

            dataUpdated = false;
            this.Close();
        }

        private void btnUpdateModify_Click(object sender, EventArgs e)
        {
            try
            {
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();

                if (btnUpdateModify.Tag.Equals("0"))
                {
                    btnUpdateModify.Text = "Update";
                    btnUpdateModify.Tag = "1";
                    btnUpdate_Cancel.Visible = true;

                    tbInfo_Label.ReadOnly = false;
                    tbInfo_Tag.ReadOnly = false;
                    tbInfo_Desc.ReadOnly = false;
                }
                else
                {
                    // Field validations

                    generalErrorToolTip.Active = false;
                    generalErrorToolTip.RemoveAll();

                    if (!Common.TextBoxIsValid(tbInfo_Label, generalErrorToolTip, true, 30))
                        return;
                    if (!Common.TextBoxIsValid(tbInfo_Tag, generalErrorToolTip, false, 30))
                        return;

                    // Data(existence) validation

                    if (Common.ValueExistInTable("Category", "Category_Label = '" + tbInfo_Label.Text + "'") && !tbInfo_Label.Text.Equals(ori_categoryLabel))
                        Common.ShowErrorToolTip(generalErrorToolTip, "The category label already exist, please chose another", tbInfo_Label);
                    else
                    {
                        int result = Common.DoSqlNonQuery("UPDATE Category SET Category_Label = '" + tbInfo_Label.Text + "', Category_Tag = '" + tbInfo_Tag.Text +
                                                          "', Category_Description = '" + tbInfo_Desc.Text + "' WHERE Category_ID = " + lblInfo_ID.Text + ";");

                        if (result == 0)
                            MessageBox.Show("An error occurred, records not affected", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        else
                        {
                            dataUpdated = true;
                            btnUpdate_Cancel_Click(btnUpdate_Cancel, e);
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

    }
}
