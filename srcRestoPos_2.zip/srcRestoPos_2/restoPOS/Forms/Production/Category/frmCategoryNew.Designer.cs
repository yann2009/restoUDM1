﻿namespace restoPOS.Forms.Production.Category
{
    partial class frmCategoryNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblNew_Label = new System.Windows.Forms.Label();
            this.btnNew_Cancel = new System.Windows.Forms.Button();
            this.tbNew_Desc = new System.Windows.Forms.TextBox();
            this.tbNew_Label = new System.Windows.Forms.TextBox();
            this.tbNew_Tag = new System.Windows.Forms.TextBox();
            this.btnNew_OK = new System.Windows.Forms.Button();
            this.lblNew_Tag = new System.Windows.Forms.Label();
            this.lblNew_Desc = new System.Windows.Forms.Label();
            this.generalErrorToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.gbNew = new System.Windows.Forms.GroupBox();
            this.gbNew.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNew_Label
            // 
            this.lblNew_Label.AutoSize = true;
            this.lblNew_Label.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Label.ForeColor = System.Drawing.Color.White;
            this.lblNew_Label.Location = new System.Drawing.Point(8, 37);
            this.lblNew_Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNew_Label.Name = "lblNew_Label";
            this.lblNew_Label.Size = new System.Drawing.Size(109, 19);
            this.lblNew_Label.TabIndex = 0;
            this.lblNew_Label.Text = "Category Label :";
            // 
            // btnNew_Cancel
            // 
            this.btnNew_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_Cancel.ForeColor = System.Drawing.Color.Black;
            this.btnNew_Cancel.Location = new System.Drawing.Point(120, 295);
            this.btnNew_Cancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnNew_Cancel.Name = "btnNew_Cancel";
            this.btnNew_Cancel.Size = new System.Drawing.Size(100, 28);
            this.btnNew_Cancel.TabIndex = 6;
            this.btnNew_Cancel.Text = "Cancel";
            this.btnNew_Cancel.UseVisualStyleBackColor = true;
            this.btnNew_Cancel.Click += new System.EventHandler(this.btnNew_Cancel_Click);
            // 
            // tbNew_Desc
            // 
            this.tbNew_Desc.Location = new System.Drawing.Point(12, 130);
            this.tbNew_Desc.Margin = new System.Windows.Forms.Padding(4);
            this.tbNew_Desc.Multiline = true;
            this.tbNew_Desc.Name = "tbNew_Desc";
            this.tbNew_Desc.Size = new System.Drawing.Size(473, 157);
            this.tbNew_Desc.TabIndex = 3;
            this.tbNew_Desc.Tag = "";
            // 
            // tbNew_Label
            // 
            this.tbNew_Label.Location = new System.Drawing.Point(136, 30);
            this.tbNew_Label.Margin = new System.Windows.Forms.Padding(4);
            this.tbNew_Label.Name = "tbNew_Label";
            this.tbNew_Label.Size = new System.Drawing.Size(349, 29);
            this.tbNew_Label.TabIndex = 1;
            this.tbNew_Label.Tag = "";
            this.tbNew_Label.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // tbNew_Tag
            // 
            this.tbNew_Tag.Location = new System.Drawing.Point(136, 68);
            this.tbNew_Tag.Margin = new System.Windows.Forms.Padding(4);
            this.tbNew_Tag.Name = "tbNew_Tag";
            this.tbNew_Tag.Size = new System.Drawing.Size(349, 29);
            this.tbNew_Tag.TabIndex = 2;
            this.tbNew_Tag.Tag = "";
            this.tbNew_Tag.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // btnNew_OK
            // 
            this.btnNew_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_OK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_OK.ForeColor = System.Drawing.Color.Black;
            this.btnNew_OK.Location = new System.Drawing.Point(12, 295);
            this.btnNew_OK.Margin = new System.Windows.Forms.Padding(4);
            this.btnNew_OK.Name = "btnNew_OK";
            this.btnNew_OK.Size = new System.Drawing.Size(100, 28);
            this.btnNew_OK.TabIndex = 5;
            this.btnNew_OK.Text = "OK";
            this.btnNew_OK.UseVisualStyleBackColor = true;
            this.btnNew_OK.Click += new System.EventHandler(this.btnNew_OK_Click);
            // 
            // lblNew_Tag
            // 
            this.lblNew_Tag.AutoSize = true;
            this.lblNew_Tag.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Tag.ForeColor = System.Drawing.Color.White;
            this.lblNew_Tag.Location = new System.Drawing.Point(8, 75);
            this.lblNew_Tag.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNew_Tag.Name = "lblNew_Tag";
            this.lblNew_Tag.Size = new System.Drawing.Size(99, 19);
            this.lblNew_Tag.TabIndex = 2;
            this.lblNew_Tag.Text = "Category Tag :";
            // 
            // lblNew_Desc
            // 
            this.lblNew_Desc.AutoSize = true;
            this.lblNew_Desc.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Desc.ForeColor = System.Drawing.Color.White;
            this.lblNew_Desc.Location = new System.Drawing.Point(8, 111);
            this.lblNew_Desc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNew_Desc.Name = "lblNew_Desc";
            this.lblNew_Desc.Size = new System.Drawing.Size(148, 19);
            this.lblNew_Desc.TabIndex = 4;
            this.lblNew_Desc.Text = "Category Description :";
            // 
            // generalErrorToolTip
            // 
            this.generalErrorToolTip.IsBalloon = true;
            this.generalErrorToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.generalErrorToolTip.ToolTipTitle = "Error";
            // 
            // gbNew
            // 
            this.gbNew.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbNew.Controls.Add(this.lblNew_Label);
            this.gbNew.Controls.Add(this.btnNew_Cancel);
            this.gbNew.Controls.Add(this.tbNew_Desc);
            this.gbNew.Controls.Add(this.tbNew_Label);
            this.gbNew.Controls.Add(this.tbNew_Tag);
            this.gbNew.Controls.Add(this.btnNew_OK);
            this.gbNew.Controls.Add(this.lblNew_Tag);
            this.gbNew.Controls.Add(this.lblNew_Desc);
            this.gbNew.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbNew.ForeColor = System.Drawing.Color.White;
            this.gbNew.Location = new System.Drawing.Point(152, 78);
            this.gbNew.Margin = new System.Windows.Forms.Padding(4);
            this.gbNew.Name = "gbNew";
            this.gbNew.Padding = new System.Windows.Forms.Padding(4);
            this.gbNew.Size = new System.Drawing.Size(495, 331);
            this.gbNew.TabIndex = 9;
            this.gbNew.TabStop = false;
            this.gbNew.Text = "New Category";
            // 
            // frmCategoryNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(798, 492);
            this.Controls.Add(this.gbNew);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCategoryNew";
            this.Opacity = 0D;
            this.ShowInTaskbar = false;
            this.Text = "frmCategoryNew";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.gbNew.ResumeLayout(false);
            this.gbNew.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNew_Label;
        private System.Windows.Forms.Button btnNew_Cancel;
        private System.Windows.Forms.TextBox tbNew_Desc;
        private System.Windows.Forms.TextBox tbNew_Label;
        private System.Windows.Forms.TextBox tbNew_Tag;
        private System.Windows.Forms.Button btnNew_OK;
        private System.Windows.Forms.Label lblNew_Tag;
        private System.Windows.Forms.Label lblNew_Desc;
        private System.Windows.Forms.ToolTip generalErrorToolTip;
        private System.Windows.Forms.GroupBox gbNew;
    }
}