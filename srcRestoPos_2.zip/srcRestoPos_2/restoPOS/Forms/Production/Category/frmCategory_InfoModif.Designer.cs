﻿namespace restoPOS.Forms.Production.Category
{
    partial class frmCategory_InfoModif
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnUpdate_Cancel = new System.Windows.Forms.Button();
            this.lblInfo_ID = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.btnUpdateModify = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.tbInfo_Desc = new System.Windows.Forms.TextBox();
            this.lblDesc = new System.Windows.Forms.Label();
            this.tbInfo_Tag = new System.Windows.Forms.TextBox();
            this.generalErrorToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.flpProductCategorizer = new System.Windows.Forms.FlowLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.lblTag = new System.Windows.Forms.Label();
            this.tbInfo_Label = new System.Windows.Forms.TextBox();
            this.lblLabel = new System.Windows.Forms.Label();
            this.lblNoProduct = new System.Windows.Forms.Label();
            this.gbInfo = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.flpProductCategorizer.SuspendLayout();
            this.gbInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnUpdate_Cancel
            // 
            this.btnUpdate_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate_Cancel.Location = new System.Drawing.Point(315, 425);
            this.btnUpdate_Cancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdate_Cancel.Name = "btnUpdate_Cancel";
            this.btnUpdate_Cancel.Size = new System.Drawing.Size(100, 28);
            this.btnUpdate_Cancel.TabIndex = 9;
            this.btnUpdate_Cancel.Tag = "0";
            this.btnUpdate_Cancel.Text = "Cancel";
            this.btnUpdate_Cancel.UseVisualStyleBackColor = true;
            this.btnUpdate_Cancel.Visible = false;
            this.btnUpdate_Cancel.Click += new System.EventHandler(this.btnUpdate_Cancel_Click);
            // 
            // lblInfo_ID
            // 
            this.lblInfo_ID.AutoSize = true;
            this.lblInfo_ID.Location = new System.Drawing.Point(129, 25);
            this.lblInfo_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInfo_ID.Name = "lblInfo_ID";
            this.lblInfo_ID.Size = new System.Drawing.Size(32, 17);
            this.lblInfo_ID.TabIndex = 8;
            this.lblInfo_ID.Text = "001";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(9, 25);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(90, 17);
            this.lblID.TabIndex = 7;
            this.lblID.Text = "Category ID :";
            // 
            // btnUpdateModify
            // 
            this.btnUpdateModify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateModify.Location = new System.Drawing.Point(423, 425);
            this.btnUpdateModify.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateModify.Name = "btnUpdateModify";
            this.btnUpdateModify.Size = new System.Drawing.Size(100, 28);
            this.btnUpdateModify.TabIndex = 6;
            this.btnUpdateModify.Tag = "0";
            this.btnUpdateModify.Text = "Modify";
            this.btnUpdateModify.UseVisualStyleBackColor = true;
            this.btnUpdateModify.Click += new System.EventHandler(this.btnUpdateModify_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBack.Location = new System.Drawing.Point(12, 425);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 28);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // tbInfo_Desc
            // 
            this.tbInfo_Desc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbInfo_Desc.Location = new System.Drawing.Point(13, 138);
            this.tbInfo_Desc.Margin = new System.Windows.Forms.Padding(4);
            this.tbInfo_Desc.Multiline = true;
            this.tbInfo_Desc.Name = "tbInfo_Desc";
            this.tbInfo_Desc.ReadOnly = true;
            this.tbInfo_Desc.Size = new System.Drawing.Size(508, 278);
            this.tbInfo_Desc.TabIndex = 3;
            this.tbInfo_Desc.Tag = "";
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Location = new System.Drawing.Point(9, 118);
            this.lblDesc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(148, 17);
            this.lblDesc.TabIndex = 4;
            this.lblDesc.Text = "Category Description :";
            // 
            // tbInfo_Tag
            // 
            this.tbInfo_Tag.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbInfo_Tag.Location = new System.Drawing.Point(129, 82);
            this.tbInfo_Tag.Margin = new System.Windows.Forms.Padding(4);
            this.tbInfo_Tag.Name = "tbInfo_Tag";
            this.tbInfo_Tag.ReadOnly = true;
            this.tbInfo_Tag.Size = new System.Drawing.Size(392, 22);
            this.tbInfo_Tag.TabIndex = 2;
            this.tbInfo_Tag.Tag = "";
            this.tbInfo_Tag.TabIndexChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // generalErrorToolTip
            // 
            this.generalErrorToolTip.IsBalloon = true;
            this.generalErrorToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.generalErrorToolTip.ToolTipTitle = "Error";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(4, 4);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(304, 28);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // flpProductCategorizer
            // 
            this.flpProductCategorizer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpProductCategorizer.AutoScroll = true;
            this.flpProductCategorizer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpProductCategorizer.Controls.Add(this.button1);
            this.flpProductCategorizer.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpProductCategorizer.Location = new System.Drawing.Point(561, 61);
            this.flpProductCategorizer.Margin = new System.Windows.Forms.Padding(4);
            this.flpProductCategorizer.Name = "flpProductCategorizer";
            this.flpProductCategorizer.Size = new System.Drawing.Size(337, 452);
            this.flpProductCategorizer.TabIndex = 15;
            this.flpProductCategorizer.WrapContents = false;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(556, 13);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 37);
            this.label5.TabIndex = 14;
            this.label5.Text = "Related Products :";
            // 
            // lblTag
            // 
            this.lblTag.AutoSize = true;
            this.lblTag.Location = new System.Drawing.Point(9, 86);
            this.lblTag.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTag.Name = "lblTag";
            this.lblTag.Size = new System.Drawing.Size(102, 17);
            this.lblTag.TabIndex = 2;
            this.lblTag.Text = "Category Tag :";
            // 
            // tbInfo_Label
            // 
            this.tbInfo_Label.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbInfo_Label.Location = new System.Drawing.Point(129, 50);
            this.tbInfo_Label.Margin = new System.Windows.Forms.Padding(4);
            this.tbInfo_Label.Name = "tbInfo_Label";
            this.tbInfo_Label.ReadOnly = true;
            this.tbInfo_Label.Size = new System.Drawing.Size(392, 22);
            this.tbInfo_Label.TabIndex = 1;
            this.tbInfo_Label.Tag = "";
            this.tbInfo_Label.TabIndexChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // lblLabel
            // 
            this.lblLabel.AutoSize = true;
            this.lblLabel.Location = new System.Drawing.Point(9, 54);
            this.lblLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLabel.Name = "lblLabel";
            this.lblLabel.Size = new System.Drawing.Size(112, 17);
            this.lblLabel.TabIndex = 0;
            this.lblLabel.Text = "Category Label :";
            // 
            // lblNoProduct
            // 
            this.lblNoProduct.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblNoProduct.AutoSize = true;
            this.lblNoProduct.Font = new System.Drawing.Font("Segoe UI", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblNoProduct.Location = new System.Drawing.Point(580, 256);
            this.lblNoProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNoProduct.Name = "lblNoProduct";
            this.lblNoProduct.Size = new System.Drawing.Size(298, 62);
            this.lblNoProduct.TabIndex = 16;
            this.lblNoProduct.Text = "No Products";
            // 
            // gbInfo
            // 
            this.gbInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbInfo.Controls.Add(this.btnBack);
            this.gbInfo.Controls.Add(this.btnUpdate_Cancel);
            this.gbInfo.Controls.Add(this.lblInfo_ID);
            this.gbInfo.Controls.Add(this.lblID);
            this.gbInfo.Controls.Add(this.btnUpdateModify);
            this.gbInfo.Controls.Add(this.tbInfo_Desc);
            this.gbInfo.Controls.Add(this.lblDesc);
            this.gbInfo.Controls.Add(this.tbInfo_Tag);
            this.gbInfo.Controls.Add(this.lblTag);
            this.gbInfo.Controls.Add(this.tbInfo_Label);
            this.gbInfo.Controls.Add(this.lblLabel);
            this.gbInfo.Location = new System.Drawing.Point(23, 54);
            this.gbInfo.Margin = new System.Windows.Forms.Padding(4);
            this.gbInfo.Name = "gbInfo";
            this.gbInfo.Padding = new System.Windows.Forms.Padding(4);
            this.gbInfo.Size = new System.Drawing.Size(531, 460);
            this.gbInfo.TabIndex = 13;
            this.gbInfo.TabStop = false;
            this.gbInfo.Text = "New Category";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(16, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 37);
            this.label1.TabIndex = 12;
            this.label1.Text = "Categories :";
            // 
            // frmCategory_InfoModif
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 527);
            this.Controls.Add(this.flpProductCategorizer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblNoProduct);
            this.Controls.Add(this.gbInfo);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCategory_InfoModif";
            this.Text = "frmCategory_InfoModif";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.flpProductCategorizer.ResumeLayout(false);
            this.gbInfo.ResumeLayout(false);
            this.gbInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate_Cancel;
        private System.Windows.Forms.Label lblInfo_ID;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Button btnUpdateModify;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox tbInfo_Desc;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.TextBox tbInfo_Tag;
        private System.Windows.Forms.ToolTip generalErrorToolTip;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.FlowLayoutPanel flpProductCategorizer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblTag;
        private System.Windows.Forms.TextBox tbInfo_Label;
        private System.Windows.Forms.Label lblLabel;
        private System.Windows.Forms.Label lblNoProduct;
        private System.Windows.Forms.GroupBox gbInfo;
        private System.Windows.Forms.Label label1;
    }
}