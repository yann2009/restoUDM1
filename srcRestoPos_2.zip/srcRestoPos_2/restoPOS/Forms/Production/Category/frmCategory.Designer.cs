﻿namespace restoPOS.Forms.Production.Category
{
    partial class frmCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCategory));
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.flpCategorizer = new System.Windows.Forms.FlowLayoutPanel();
            this.pcSub_Delete = new System.Windows.Forms.PictureBox();
            this.pnlSub_Pannel = new System.Windows.Forms.Panel();
            this.lblSub_Name = new System.Windows.Forms.Label();
            this.lblSub_Info = new System.Windows.Forms.Label();
            this.pcSub_Info = new System.Windows.Forms.PictureBox();
            this.lblSub_Delete = new System.Windows.Forms.Label();
            this.lblNoContent = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Delete)).BeginInit();
            this.pnlSub_Pannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Info)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnAddCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCategory.Location = new System.Drawing.Point(718, 129);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(24, 198);
            this.btnAddCategory.TabIndex = 6;
            this.btnAddCategory.Tag = "0";
            this.btnAddCategory.Text = "+";
            this.btnAddCategory.UseVisualStyleBackColor = true;
            this.btnAddCategory.Click += new System.EventHandler(this.btnAddCategory_Click);
            // 
            // flpCategorizer
            // 
            this.flpCategorizer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpCategorizer.AutoScroll = true;
            this.flpCategorizer.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpCategorizer.Location = new System.Drawing.Point(15, 41);
            this.flpCategorizer.Name = "flpCategorizer";
            this.flpCategorizer.Size = new System.Drawing.Size(698, 376);
            this.flpCategorizer.TabIndex = 5;
            // 
            // pcSub_Delete
            // 
            this.pcSub_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pcSub_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcSub_Delete.Image = ((System.Drawing.Image)(resources.GetObject("pcSub_Delete.Image")));
            this.pcSub_Delete.Location = new System.Drawing.Point(478, 8);
            this.pcSub_Delete.Name = "pcSub_Delete";
            this.pcSub_Delete.Size = new System.Drawing.Size(20, 26);
            this.pcSub_Delete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcSub_Delete.TabIndex = 0;
            this.pcSub_Delete.TabStop = false;
            this.pcSub_Delete.Click += new System.EventHandler(this.DeleteRecord);
            // 
            // pnlSub_Pannel
            // 
            this.pnlSub_Pannel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlSub_Pannel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Name);
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Info);
            this.pnlSub_Pannel.Controls.Add(this.pcSub_Info);
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Delete);
            this.pnlSub_Pannel.Controls.Add(this.pcSub_Delete);
            this.pnlSub_Pannel.Location = new System.Drawing.Point(-1, 424);
            this.pnlSub_Pannel.Name = "pnlSub_Pannel";
            this.pnlSub_Pannel.Size = new System.Drawing.Size(745, 41);
            this.pnlSub_Pannel.TabIndex = 7;
            this.pnlSub_Pannel.Tag = "NONE";
            // 
            // lblSub_Name
            // 
            this.lblSub_Name.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Name.ForeColor = System.Drawing.Color.White;
            this.lblSub_Name.Location = new System.Drawing.Point(12, 11);
            this.lblSub_Name.Name = "lblSub_Name";
            this.lblSub_Name.Size = new System.Drawing.Size(453, 21);
            this.lblSub_Name.TabIndex = 4;
            this.lblSub_Name.Text = "Category 001";
            // 
            // lblSub_Info
            // 
            this.lblSub_Info.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Info.AutoSize = true;
            this.lblSub_Info.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSub_Info.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Info.ForeColor = System.Drawing.Color.White;
            this.lblSub_Info.Location = new System.Drawing.Point(633, 14);
            this.lblSub_Info.Name = "lblSub_Info";
            this.lblSub_Info.Size = new System.Drawing.Size(109, 13);
            this.lblSub_Info.TabIndex = 3;
            this.lblSub_Info.Text = "Modify/Information";
            this.lblSub_Info.Click += new System.EventHandler(this.Info_Modif);
            // 
            // pcSub_Info
            // 
            this.pcSub_Info.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pcSub_Info.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcSub_Info.Image = ((System.Drawing.Image)(resources.GetObject("pcSub_Info.Image")));
            this.pcSub_Info.Location = new System.Drawing.Point(607, 8);
            this.pcSub_Info.Name = "pcSub_Info";
            this.pcSub_Info.Size = new System.Drawing.Size(20, 26);
            this.pcSub_Info.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcSub_Info.TabIndex = 2;
            this.pcSub_Info.TabStop = false;
            this.pcSub_Info.Click += new System.EventHandler(this.Info_Modif);
            // 
            // lblSub_Delete
            // 
            this.lblSub_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Delete.AutoSize = true;
            this.lblSub_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSub_Delete.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Delete.ForeColor = System.Drawing.Color.White;
            this.lblSub_Delete.Location = new System.Drawing.Point(504, 14);
            this.lblSub_Delete.Name = "lblSub_Delete";
            this.lblSub_Delete.Size = new System.Drawing.Size(90, 13);
            this.lblSub_Delete.TabIndex = 1;
            this.lblSub_Delete.Text = "Delete Category";
            this.lblSub_Delete.Click += new System.EventHandler(this.DeleteRecord);
            // 
            // lblNoContent
            // 
            this.lblNoContent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNoContent.AutoSize = true;
            this.lblNoContent.Font = new System.Drawing.Font("Segoe UI", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoContent.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblNoContent.Location = new System.Drawing.Point(222, 197);
            this.lblNoContent.Name = "lblNoContent";
            this.lblNoContent.Size = new System.Drawing.Size(284, 65);
            this.lblNoContent.TabIndex = 8;
            this.lblNoContent.Text = "No Content";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(10, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 30);
            this.label1.TabIndex = 9;
            this.label1.Text = "Categories :";
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBack.Location = new System.Drawing.Point(14, 433);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 33;
            this.btnBack.Text = "<< Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(744, 465);
            this.Controls.Add(this.btnAddCategory);
            this.Controls.Add(this.pnlSub_Pannel);
            this.Controls.Add(this.lblNoContent);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flpCategorizer);
            this.Controls.Add(this.btnBack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmCategory";
            this.Text = "frmCategory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Delete)).EndInit();
            this.pnlSub_Pannel.ResumeLayout(false);
            this.pnlSub_Pannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Info)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.FlowLayoutPanel flpCategorizer;
        private System.Windows.Forms.PictureBox pcSub_Delete;
        private System.Windows.Forms.Panel pnlSub_Pannel;
        private System.Windows.Forms.Label lblSub_Name;
        private System.Windows.Forms.Label lblSub_Info;
        private System.Windows.Forms.PictureBox pcSub_Info;
        private System.Windows.Forms.Label lblSub_Delete;
        private System.Windows.Forms.Label lblNoContent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
    }
}