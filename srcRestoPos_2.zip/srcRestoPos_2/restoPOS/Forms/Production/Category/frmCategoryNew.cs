﻿/************************************************************************
	Filename 	 :	frmCategory_New.cs
	Created  	 :	28/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Form to add new category to the database
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;

namespace restoPOS.Forms.Production.Category
{
    public partial class frmCategoryNew : Form
    {
        public delegate void AnnounceParentHandler();

        public event AnnounceParentHandler FormHidden;
        public event AnnounceParentHandler DataUpdated;

        private string txtLabel;

        public string tbLabel
        {
            get { return txtLabel; }
            set { txtLabel = value; }
        }

        public frmCategoryNew()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Hides the form and reset all fields to its original state</summary>
        private void HideMe()
        {
            tbNew_Label.Text = tbNew_Desc.Text = tbNew_Tag.Text = "";

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            FormHidden();
            Animation.FadeOut(this, 5);
        }

        private void btnNew_Cancel_Click(object sender, EventArgs e)
        {
            HideMe();
        }

        private void TBs_TextChanged(object sender, EventArgs e)
        {
            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            TextBox textbox = (TextBox)sender;

            if (textbox.Name.Equals("tbNew_Label"))
                Common.TextBoxIsValid(tbNew_Label, generalErrorToolTip, true, 30);
            if (textbox.Name.Equals("tbNew_Tag"))
                Common.TextBoxIsValid(tbNew_Tag, generalErrorToolTip, false, 30);
        }

        private void btnNew_OK_Click(object sender, EventArgs e)
        {
            try
            {
                // Field validations

                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();

                if (!Common.TextBoxIsValid(tbNew_Label, generalErrorToolTip, true, 30))
                    return;
                if (!Common.TextBoxIsValid(tbNew_Tag, generalErrorToolTip, false, 30))
                    return;

                // Data(existence) validation

                if (Common.ValueExistInTable("Category", "Category_Label = '" + tbNew_Label.Text + "'"))
                    Common.ShowErrorToolTip(generalErrorToolTip, "The category label already exist, please choose another", tbNew_Label);
                else
                {
                    int result = Common.DoSqlNonQuery("INSERT INTO Category (Category_Label, Category_Description, Category_Tag) " +
                                                      "VALUES ('" + tbNew_Label.Text + "', '" + tbNew_Desc.Text + "', '" + tbNew_Tag.Text + "')");

                    if (result == 0)
                        MessageBox.Show("An error occurred, records not affected", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        tbLabel = tbNew_Label.Text;
                        DataUpdated();
                        HideMe();
                    }
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();
                MessageBox.Show(ex.Message, "Error");
            }
        }
    }
}
