﻿/************************************************************************
	Filename 	 :	frmCategory.cs
	Created  	 :	28/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Main category form
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;

namespace restoPOS.Forms.Production.Category
{
    public partial class frmCategory : Form
    {
        private bool subPanel_isHidden = false;

        private string selectedCategoryID = "NONE";
        private string selectedCategoryLabel = "";

        public frmCategoryNew newCategoryForm = new frmCategoryNew();

        public frmCategory()
        {
            InitializeComponent();
            newCategoryForm.FormHidden += new Category.frmCategoryNew.AnnounceParentHandler(() => { });
            newCategoryForm.DataUpdated += new Category.frmCategoryNew.AnnounceParentHandler(() => {
                PopulateCategories();
            });

            Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5, 0);
            PopulateCategories();
        }

        /// <summary>
        /// Populates the Category list</summary>
        public void PopulateCategories()
        {
            try
            {
                flpCategorizer.Controls.Clear();

                Hashtable categoryInfo = Common.DoSqlQuery("SELECT Category_ID, Category_Label FROM Category " +
                                                           "ORDER BY Category_Label DESC", new short[] { 0, 1 });
                int controlIndex = 0;
                foreach (DictionaryEntry row in categoryInfo)
                {
                    Button controlButton = new Button();
                    controlButton.Name = "flpControl" + controlIndex++;
                    controlButton.Tag = Convert.ToString(((Hashtable)row.Value)[0]);   // Category_ID
                    controlButton.Text = Convert.ToString(((Hashtable)row.Value)[1]);   // Category_Label
                    controlButton.AutoSize = true;
                    controlButton.Click += new EventHandler(flpCategorizerControl_Click);

                    flpCategorizer.Controls.Add(controlButton);
                }

                if (flpCategorizer.Controls.Count == 0)
                    lblNoContent.Visible = true;
                else
                    lblNoContent.Visible = false;
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Handles the click event of flpCategorizers' controls</summary>
        private void flpCategorizerControl_Click(object sender, EventArgs e)
        {
            selectedCategoryID = ((Button)sender).Tag.ToString();
            selectedCategoryLabel = ((Button)sender).Text;
            string subPanel = pnlSub_Pannel.Tag.ToString();

            if (!subPanel.Equals("NONE") && !subPanel.Equals(selectedCategoryID) && !subPanel_isHidden)
            {
                Animation.AnimationToggle(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5, 0);
                pnlSub_Pannel.Tag = selectedCategoryID;
                lblSub_Name.Text = selectedCategoryLabel;
                Animation.AnimationToggle(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
            }
            else
            {
                pnlSub_Pannel.Tag = selectedCategoryID;
                lblSub_Name.Text = selectedCategoryLabel;
                Animation.AnimationToggle(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
            }
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);

            newCategoryForm.Show();
            newCategoryForm.Size = this.Size;
            newCategoryForm.Location = this.Location;
            newCategoryForm.TopMost = true;
            Animation.FadeIn(newCategoryForm, 90, 5);
        }

        private void Info_Modif(object sender, EventArgs e)
        {
            Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
            
            frmCategory_InfoModif imCategoryForm = new frmCategory_InfoModif(selectedCategoryID, this);
            imCategoryForm.Show();
        }

        /// <summary>
        /// Method to delete records in the category context</summary>
        private void DeleteRecord(object sender, EventArgs e)
        {
            try
            {
                if (Common.DeleteRecord("Are you sure you want to delete the '" + selectedCategoryLabel + "' category? This action cannot be undone ",
                                        "Delete category", "DELETE FROM Category WHERE Category_ID = " + selectedCategoryID))
                {
                    Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
                    PopulateCategories();
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
