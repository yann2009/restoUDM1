﻿/**
 * recipe_backOffice
 * Programmed by Y A Jaunky
 * 05/11/2013
 * Form for adding new recipes
 **/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;


namespace restoPOS.Forms.Production.Recipe
{
    public partial class recipe_backOffice : Form
    {
        public recipe_backOffice()
        {
            InitializeComponent();
        }

        private void recipe_backOffice_Load(object sender, EventArgs e)
        {

        }

        private void cbCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            Hashtable categoryInfo = Common.DoSqlQuery("SELECT Category_Label FROM Category " +
                                                           "ORDER BY Category_Label DESC", new short[] { 0 });

            using (SqlDataReader rdr = cmd.ExecuteReader())
            {
            if (rdr.HasRows)
            {
                while (rdr.Read())
                   {
                       cbCategories.Items.Add(rdr.GetValue(0));
                   }
            }
            }
        }
    }
}
