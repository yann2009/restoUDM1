﻿namespace restoPOS.Forms.Production.Recipe
{
    partial class recipe_backOffice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLib = new System.Windows.Forms.TextBox();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.cbCategories = new System.Windows.Forms.ComboBox();
            this.lblLib = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtLib
            // 
            this.txtLib.Location = new System.Drawing.Point(165, 104);
            this.txtLib.Name = "txtLib";
            this.txtLib.Size = new System.Drawing.Size(135, 20);
            this.txtLib.TabIndex = 0;
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(77, 167);
            this.txtDesc.Multiline = true;
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtDesc.Size = new System.Drawing.Size(611, 325);
            this.txtDesc.TabIndex = 1;
            // 
            // cbCategories
            // 
            this.cbCategories.FormattingEnabled = true;
            this.cbCategories.Location = new System.Drawing.Point(165, 64);
            this.cbCategories.Name = "cbCategories";
            this.cbCategories.Size = new System.Drawing.Size(121, 21);
            this.cbCategories.TabIndex = 2;
            this.cbCategories.Text = "Choose Categories";
            this.cbCategories.SelectedIndexChanged += new System.EventHandler(this.cbCategories_SelectedIndexChanged);
            // 
            // lblLib
            // 
            this.lblLib.AutoSize = true;
            this.lblLib.Location = new System.Drawing.Point(80, 107);
            this.lblLib.Name = "lblLib";
            this.lblLib.Size = new System.Drawing.Size(82, 13);
            this.lblLib.TabIndex = 3;
            this.lblLib.Text = "Name of recipe:";
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Location = new System.Drawing.Point(80, 151);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(63, 13);
            this.lblDesc.TabIndex = 4;
            this.lblDesc.Text = "Description:";
            // 
            // recipe_backOffice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(890, 504);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.lblLib);
            this.Controls.Add(this.cbCategories);
            this.Controls.Add(this.txtDesc);
            this.Controls.Add(this.txtLib);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "recipe_backOffice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "recipe_backOffice";
            this.Load += new System.EventHandler(this.recipe_backOffice_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLib;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.ComboBox cbCategories;
        private System.Windows.Forms.Label lblLib;
        private System.Windows.Forms.Label lblDesc;
    }
}