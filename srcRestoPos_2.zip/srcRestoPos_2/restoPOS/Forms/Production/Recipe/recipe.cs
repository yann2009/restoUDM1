﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace restoPOS.Forms.Production.recipe
{
    public partial class recipe : Form
    {
        public recipe()
        {
            InitializeComponent();
            lbRecipe.Items.Add("salmon with a cheesy crunch crust");
            lbRecipe.Items.Add("lasagna");
            
        }

        private void lbRecipe_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbRecipe.SelectedIndex == 0)
                label1.Text = "To prepare salmon with a cheesy crunch crust, you'll need 4*175g of salmon fillet,\n50g softened butter will be needed,\n4 tbsp slivered or flaked almonds will also be needed.\n 4 tbsp of freshly chopped parsley and \n50 g of coarsly grated emmental, which can be replaced by Gruyere";
        }

    }
}
