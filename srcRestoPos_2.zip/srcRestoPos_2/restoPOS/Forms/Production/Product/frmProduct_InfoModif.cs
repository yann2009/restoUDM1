﻿/************************************************************************
	Filename 	 :	Animation.cs
	Created  	 :	2/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Form to view, update and modify products
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using restoPOS.Commons;

namespace restoPOS.Forms.Production.Product
{
    public partial class frmProduct_InfoModif : Form
    {
        public delegate void AnnounceParentHandler();
        public event AnnounceParentHandler FormHidden;

        public delegate void UpdateAnnounceParentHandler(string strLabel);
        public event UpdateAnnounceParentHandler DataUpdated;

        private string ori_productID;
        private string ori_productLabel;

        public Category.frmCategoryNew newCategoryForm = new Category.frmCategoryNew();

        public frmProduct_InfoModif()
        {
            InitializeComponent();

            newCategoryForm.FormHidden += new Category.frmCategoryNew.AnnounceParentHandler(() => {
                this.Show();
                Animation.FadeIn(this, 90, 5);
            });

            newCategoryForm.DataUpdated += new Category.frmCategoryNew.AnnounceParentHandler(() => {
                PopulateCategoryList();
                cbNew_Category.Text = newCategoryForm.tbLabel;
            });
        }

        public string ProductID
        {
            set { ori_productID = lblID.Text = value; UpdateInformation(); }
        }

        /// <summary>
        /// Updates the product field of the form</summary>
        /// <param name="productID">
        /// The ID of the product</param>
        private void UpdateInformation()
        {
            try
            {
                PopulateCategoryList();

                //BUG: Exception when no field exist in database - DoSqlQuery

                // Updates the fields
                Hashtable categoryLabels = Common.DoSqlQuery("SELECT Product_Label, Product_Description, Product_Barcode, Product_Tag, Product_Tax, Product_Category " +
                                           "FROM Product WHERE Product_ID = " + ori_productID, new short[] { 0, 1, 2, 3, 4, 5 });

                string categoryID = Convert.ToString(((Hashtable)categoryLabels[0])[5]);
                if (!categoryID.Equals(""))
                {
                    Hashtable catLabel = Common.DoSqlQuery("SELECT Category_Label FROM Category WHERE Category_ID = " + categoryID, new short[] { 0 });
                    cbNew_Category.Text = Convert.ToString(((Hashtable)catLabel[0])[0]);
                }
                else
                    cbNew_Category.Text = "";

                tbNew_Label.Text = Convert.ToString(((Hashtable)categoryLabels[0])[0]);
                tbNew_Desc.Text = Convert.ToString(((Hashtable)categoryLabels[0])[1]);
                tbNew_Barcode.Text = Convert.ToString(((Hashtable)categoryLabels[0])[2]);
                tbNew_Tag.Text = Convert.ToString(((Hashtable)categoryLabels[0])[3]);
                tbNew_Tax.Text = Convert.ToString(((Hashtable)categoryLabels[0])[4]);

                ori_productLabel = Convert.ToString(((Hashtable)categoryLabels[0])[0]);
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Populates the combo box with a list of all categories</summary>
        private void PopulateCategoryList()
        {
            cbNew_Category.Items.Clear();

            Hashtable categories = Common.DoSqlQuery("SELECT Category_Label FROM Category", new short[] { 0 });
            foreach (DictionaryEntry row in categories)
                cbNew_Category.Items.Add(Convert.ToString(((Hashtable)row.Value)[0]));
        }

        /// <summary>
        /// Hides the form and reset all fields to its original state</summary>
        /// <param name="fullHide">
        /// If true erase all fields</param>
        private void HideMe(bool fullHide = true)
        {
            if (fullHide)
            {
                tbNew_Label.Text = tbNew_Desc.Text = tbNew_Tag.Text = cbNew_Category.Text = "";

                btnUpdateModify.Text = "Modify";
                btnUpdateModify.Tag = "0";
                btnUpdate_Cancel.Visible = false;

                tbNew_Label.ReadOnly = true;
                tbNew_Barcode.ReadOnly = true;
                tbNew_Tag.ReadOnly = true;
                tbNew_Desc.ReadOnly = true;

                tbNew_Tax.ReadOnly = true;
                pcntTax.BackColor = SystemColors.Control;

                cbNew_Category.DropDownStyle = ComboBoxStyle.Simple;
                cbNew_Category.AutoCompleteMode = AutoCompleteMode.None;
                cbNew_Category.AutoCompleteSource = AutoCompleteSource.None;
                btnNewCat.Enabled = false;
            }

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            FormHidden();
            Animation.FadeOut(this, 5);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            HideMe();
        }

        private void btnUpdate_Cancel_Click(object sender, EventArgs e)
        {
            btnUpdateModify.Text = "Modify";
            btnUpdateModify.Tag = "0";
            btnUpdate_Cancel.Visible = false;

            tbNew_Label.ReadOnly = true;
            tbNew_Barcode.ReadOnly = true;
            tbNew_Tag.ReadOnly = true;
            tbNew_Desc.ReadOnly = true;

            tbNew_Tax.ReadOnly = true;
            pcntTax.BackColor = SystemColors.Control;

            cbNew_Category.DropDownStyle = ComboBoxStyle.Simple;
            cbNew_Category.AutoCompleteMode = AutoCompleteMode.None;
            cbNew_Category.AutoCompleteSource = AutoCompleteSource.None;
            btnNewCat.Enabled = false;

            UpdateInformation();

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();
        }

        private void TBs_TextChanged(object sender, EventArgs e)
        {
            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            TextBox textbox = (TextBox)sender;

            if (textbox.Name.Equals("tbNew_Label"))
                Common.TextBoxIsValid(tbNew_Label, generalErrorToolTip, true, 30);
            if (textbox.Name.Equals("tbNew_Tag"))
                Common.TextBoxIsValid(tbNew_Tag, generalErrorToolTip, false, 30);
            if (textbox.Name.Equals("tbNew_Tax"))
            {
                Regex isDecimal = new Regex("^[0-9]{1,2}([.][0-9]{1,2})?$");

                if (tbNew_Tax.Text.Equals(""))
                    Common.ShowErrorToolTip(generalErrorToolTip, "Empty field", tbNew_Tax);
                else if (!isDecimal.IsMatch(tbNew_Tax.Text))
                    Common.ShowErrorToolTip(generalErrorToolTip, "Invalid tax format", tbNew_Tax);
            }
        }

        private void btnUpdateModify_Click(object sender, EventArgs e)
        {
            try
            {
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();

                if (btnUpdateModify.Tag.Equals("0"))
                {
                    btnUpdateModify.Text = "Update";
                    btnUpdateModify.Tag = "1";
                    btnUpdate_Cancel.Visible = true;

                    tbNew_Label.ReadOnly = false;
                    tbNew_Barcode.ReadOnly = false;
                    tbNew_Tag.ReadOnly = false;
                    tbNew_Desc.ReadOnly = false;

                    tbNew_Tax.ReadOnly = false;
                    pcntTax.BackColor = Color.White;

                    cbNew_Category.DropDownStyle = ComboBoxStyle.DropDown;
                    cbNew_Category.AutoCompleteMode = AutoCompleteMode.Suggest;
                    cbNew_Category.AutoCompleteSource = AutoCompleteSource.ListItems;
                    btnNewCat.Enabled = true;
                }
                else
                {
                    // Field validations

                    generalErrorToolTip.Active = false;
                    generalErrorToolTip.RemoveAll();

                    if (!Common.TextBoxIsValid(tbNew_Label, generalErrorToolTip, true, 30))
                        return;
                    if (!Common.TextBoxIsValid(tbNew_Tag, generalErrorToolTip, false, 30))
                        return;

                    Regex isDecimal = new Regex("^[0-9]{1,2}([.][0-9]{1,2})?$");
                    if (tbNew_Tax.Text.Equals(""))
                    {
                        Common.ShowErrorToolTip(generalErrorToolTip, "Empty field", tbNew_Tax);
                        return;
                    }
                    else if (!isDecimal.IsMatch(tbNew_Tax.Text))
                    {
                        Common.ShowErrorToolTip(generalErrorToolTip, "Invalid tax format", tbNew_Tax);
                        return;
                    }

                    // Data(existence) validation

                    if (!cbNew_Category.Text.Equals("") && !Common.ValueExistInTable("Category", "Category_Label = '" + cbNew_Category.Text + "'"))
                    {
                        Common.ShowErrorToolTip(generalErrorToolTip, "The category does not exist", cbNew_Category);
                        return;
                    }

                    if (Common.ValueExistInTable("Product", "Product_Label = '" + tbNew_Label.Text + "'") && !tbNew_Label.Text.Equals(ori_productLabel))
                        Common.ShowErrorToolTip(generalErrorToolTip, "The product label already exist, please chose another", tbNew_Label);
                    else
                    {
                        int result;
                        if (cbNew_Category.Text.Equals(""))
                        {
                            result = Common.DoSqlNonQuery("Update Product SET Product_Label = '" + tbNew_Label.Text +
                                                          "', Product_Description = '" + tbNew_Desc.Text + "', Product_Barcode = '" +
                                                          tbNew_Barcode.Text + "'," + " Product_Tag = '" + tbNew_Tag.Text + "',  Product_Tax = " +
                                                          tbNew_Tax.Text + " WHERE Product_ID = " + ori_productID);
                        }
                        else
                        {
                            Hashtable tblCategory = Common.DoSqlQuery("SELECT Category_ID FROM Category WHERE Category_Label = '" + cbNew_Category.Text + "'", new short[] { 0 });

                            int categoryID = (int)(((Hashtable)tblCategory[0])[0]);
                            result = Common.DoSqlNonQuery("Update Product SET Product_Label = '" + tbNew_Label.Text +
                                                          "', Product_Description = '" + tbNew_Desc.Text + "', Product_Barcode = '" +
                                                          tbNew_Barcode.Text + "'," + " Product_Tag = '" + tbNew_Tag.Text + "',  Product_Tax = " +
                                                          tbNew_Tax.Text + ", Product_Category = " + categoryID + " WHERE Product_ID = " + ori_productID);
                        }

                        if (result == 0)
                            MessageBox.Show("An error occurred, records not affected", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        else
                        {
                            DataUpdated(cbNew_Category.Text);
                            HideMe();
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnNewCat_Click(object sender, EventArgs e)
        {
            HideMe(false);

            newCategoryForm.Show();
            newCategoryForm.Size = this.Size;
            newCategoryForm.Location = this.Location;
            newCategoryForm.TopMost = true;
            newCategoryForm.tbLabel = cbNew_Category.Text;
            Animation.FadeIn(newCategoryForm, 90, 5);
        }
    }
}
