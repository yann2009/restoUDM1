﻿namespace restoPOS.Forms.Production.Product
{
    partial class frmProduct_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.generalErrorToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.btnNewCat = new System.Windows.Forms.Button();
            this.cbNew_Category = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbNew_Tax = new System.Windows.Forms.TextBox();
            this.tbNew_Barcode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNew_Label = new System.Windows.Forms.Label();
            this.btnNew_Cancel = new System.Windows.Forms.Button();
            this.tbNew_Desc = new System.Windows.Forms.TextBox();
            this.tbNew_Label = new System.Windows.Forms.TextBox();
            this.tbNew_Tag = new System.Windows.Forms.TextBox();
            this.btnNew_OK = new System.Windows.Forms.Button();
            this.lblNew_Tag = new System.Windows.Forms.Label();
            this.lblNew_Desc = new System.Windows.Forms.Label();
            this.gbNew = new System.Windows.Forms.GroupBox();
            this.gbNew.SuspendLayout();
            this.SuspendLayout();
            // 
            // generalErrorToolTip
            // 
            this.generalErrorToolTip.IsBalloon = true;
            this.generalErrorToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.generalErrorToolTip.ToolTipTitle = "Error";
            // 
            // btnNewCat
            // 
            this.btnNewCat.ForeColor = System.Drawing.Color.Black;
            this.btnNewCat.Location = new System.Drawing.Point(343, 148);
            this.btnNewCat.Name = "btnNewCat";
            this.btnNewCat.Size = new System.Drawing.Size(22, 25);
            this.btnNewCat.TabIndex = 14;
            this.btnNewCat.Text = "+";
            this.btnNewCat.UseVisualStyleBackColor = true;
            this.btnNewCat.Click += new System.EventHandler(this.btnNewCat_Click);
            // 
            // cbNew_Category
            // 
            this.cbNew_Category.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbNew_Category.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbNew_Category.FormattingEnabled = true;
            this.cbNew_Category.Location = new System.Drawing.Point(114, 148);
            this.cbNew_Category.Name = "cbNew_Category";
            this.cbNew_Category.Size = new System.Drawing.Size(223, 25);
            this.cbNew_Category.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(348, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(6, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Product Category :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Product Tax :";
            // 
            // tbNew_Tax
            // 
            this.tbNew_Tax.Location = new System.Drawing.Point(114, 86);
            this.tbNew_Tax.Name = "tbNew_Tax";
            this.tbNew_Tax.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Tax.TabIndex = 3;
            this.tbNew_Tax.Tag = "";
            this.tbNew_Tax.Text = "0.00";
            this.tbNew_Tax.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // tbNew_Barcode
            // 
            this.tbNew_Barcode.Location = new System.Drawing.Point(114, 117);
            this.tbNew_Barcode.Name = "tbNew_Barcode";
            this.tbNew_Barcode.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Barcode.TabIndex = 4;
            this.tbNew_Barcode.Tag = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Product Barcode :";
            // 
            // lblNew_Label
            // 
            this.lblNew_Label.AutoSize = true;
            this.lblNew_Label.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Label.ForeColor = System.Drawing.Color.White;
            this.lblNew_Label.Location = new System.Drawing.Point(6, 30);
            this.lblNew_Label.Name = "lblNew_Label";
            this.lblNew_Label.Size = new System.Drawing.Size(82, 13);
            this.lblNew_Label.TabIndex = 0;
            this.lblNew_Label.Text = "Product Label :";
            // 
            // btnNew_Cancel
            // 
            this.btnNew_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_Cancel.ForeColor = System.Drawing.Color.Black;
            this.btnNew_Cancel.Location = new System.Drawing.Point(90, 334);
            this.btnNew_Cancel.Name = "btnNew_Cancel";
            this.btnNew_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btnNew_Cancel.TabIndex = 8;
            this.btnNew_Cancel.Text = "Cancel";
            this.btnNew_Cancel.UseVisualStyleBackColor = true;
            this.btnNew_Cancel.Click += new System.EventHandler(this.btnNew_Cancel_Click);
            // 
            // tbNew_Desc
            // 
            this.tbNew_Desc.Location = new System.Drawing.Point(9, 198);
            this.tbNew_Desc.Multiline = true;
            this.tbNew_Desc.Name = "tbNew_Desc";
            this.tbNew_Desc.Size = new System.Drawing.Size(356, 128);
            this.tbNew_Desc.TabIndex = 6;
            this.tbNew_Desc.Tag = "";
            // 
            // tbNew_Label
            // 
            this.tbNew_Label.Location = new System.Drawing.Point(114, 24);
            this.tbNew_Label.Name = "tbNew_Label";
            this.tbNew_Label.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Label.TabIndex = 1;
            this.tbNew_Label.Tag = "";
            this.tbNew_Label.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // tbNew_Tag
            // 
            this.tbNew_Tag.Location = new System.Drawing.Point(114, 55);
            this.tbNew_Tag.Name = "tbNew_Tag";
            this.tbNew_Tag.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Tag.TabIndex = 2;
            this.tbNew_Tag.Tag = "";
            this.tbNew_Tag.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // btnNew_OK
            // 
            this.btnNew_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_OK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_OK.ForeColor = System.Drawing.Color.Black;
            this.btnNew_OK.Location = new System.Drawing.Point(9, 334);
            this.btnNew_OK.Name = "btnNew_OK";
            this.btnNew_OK.Size = new System.Drawing.Size(75, 23);
            this.btnNew_OK.TabIndex = 7;
            this.btnNew_OK.Text = "OK";
            this.btnNew_OK.UseVisualStyleBackColor = true;
            this.btnNew_OK.Click += new System.EventHandler(this.btnNew_OK_Click);
            // 
            // lblNew_Tag
            // 
            this.lblNew_Tag.AutoSize = true;
            this.lblNew_Tag.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Tag.ForeColor = System.Drawing.Color.White;
            this.lblNew_Tag.Location = new System.Drawing.Point(6, 61);
            this.lblNew_Tag.Name = "lblNew_Tag";
            this.lblNew_Tag.Size = new System.Drawing.Size(73, 13);
            this.lblNew_Tag.TabIndex = 2;
            this.lblNew_Tag.Text = "Product Tag :";
            // 
            // lblNew_Desc
            // 
            this.lblNew_Desc.AutoSize = true;
            this.lblNew_Desc.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Desc.ForeColor = System.Drawing.Color.White;
            this.lblNew_Desc.Location = new System.Drawing.Point(6, 182);
            this.lblNew_Desc.Name = "lblNew_Desc";
            this.lblNew_Desc.Size = new System.Drawing.Size(121, 13);
            this.lblNew_Desc.TabIndex = 4;
            this.lblNew_Desc.Text = "Category Description :";
            // 
            // gbNew
            // 
            this.gbNew.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbNew.Controls.Add(this.btnNewCat);
            this.gbNew.Controls.Add(this.cbNew_Category);
            this.gbNew.Controls.Add(this.label4);
            this.gbNew.Controls.Add(this.label3);
            this.gbNew.Controls.Add(this.label1);
            this.gbNew.Controls.Add(this.tbNew_Tax);
            this.gbNew.Controls.Add(this.tbNew_Barcode);
            this.gbNew.Controls.Add(this.label2);
            this.gbNew.Controls.Add(this.lblNew_Label);
            this.gbNew.Controls.Add(this.btnNew_Cancel);
            this.gbNew.Controls.Add(this.tbNew_Desc);
            this.gbNew.Controls.Add(this.tbNew_Label);
            this.gbNew.Controls.Add(this.tbNew_Tag);
            this.gbNew.Controls.Add(this.btnNew_OK);
            this.gbNew.Controls.Add(this.lblNew_Tag);
            this.gbNew.Controls.Add(this.lblNew_Desc);
            this.gbNew.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbNew.ForeColor = System.Drawing.Color.White;
            this.gbNew.Location = new System.Drawing.Point(17, 8);
            this.gbNew.Name = "gbNew";
            this.gbNew.Size = new System.Drawing.Size(376, 363);
            this.gbNew.TabIndex = 10;
            this.gbNew.TabStop = false;
            this.gbNew.Text = "New Product";
            // 
            // frmProduct_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(409, 383);
            this.Controls.Add(this.gbNew);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmProduct_New";
            this.Opacity = 0D;
            this.ShowInTaskbar = false;
            this.Text = "frmProduct_New";
            this.TopMost = true;
            this.gbNew.ResumeLayout(false);
            this.gbNew.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip generalErrorToolTip;
        private System.Windows.Forms.Button btnNewCat;
        private System.Windows.Forms.ComboBox cbNew_Category;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNew_Tax;
        private System.Windows.Forms.TextBox tbNew_Barcode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNew_Label;
        private System.Windows.Forms.Button btnNew_Cancel;
        private System.Windows.Forms.TextBox tbNew_Desc;
        private System.Windows.Forms.TextBox tbNew_Label;
        private System.Windows.Forms.TextBox tbNew_Tag;
        private System.Windows.Forms.Button btnNew_OK;
        private System.Windows.Forms.Label lblNew_Tag;
        private System.Windows.Forms.Label lblNew_Desc;
        private System.Windows.Forms.GroupBox gbNew;
    }
}