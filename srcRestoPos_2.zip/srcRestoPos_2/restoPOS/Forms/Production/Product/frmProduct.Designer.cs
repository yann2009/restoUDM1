﻿namespace restoPOS.Forms.Production.Product
{
    partial class frmProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProduct));
            this.pnlSub_Pannel = new System.Windows.Forms.Panel();
            this.lblSub_Name = new System.Windows.Forms.Label();
            this.lblSub_Info = new System.Windows.Forms.Label();
            this.pcSub_Info = new System.Windows.Forms.PictureBox();
            this.lblSub_Delete = new System.Windows.Forms.Label();
            this.pcSub_Delete = new System.Windows.Forms.PictureBox();
            this.lblNoProduct = new System.Windows.Forms.Label();
            this.flpProduct = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNoCategory = new System.Windows.Forms.Label();
            this.flpCategory = new System.Windows.Forms.FlowLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.pnlSub_Pannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Info)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Delete)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlSub_Pannel
            // 
            this.pnlSub_Pannel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlSub_Pannel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Name);
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Info);
            this.pnlSub_Pannel.Controls.Add(this.pcSub_Info);
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Delete);
            this.pnlSub_Pannel.Controls.Add(this.pcSub_Delete);
            this.pnlSub_Pannel.Location = new System.Drawing.Point(0, 424);
            this.pnlSub_Pannel.Name = "pnlSub_Pannel";
            this.pnlSub_Pannel.Size = new System.Drawing.Size(745, 41);
            this.pnlSub_Pannel.TabIndex = 30;
            this.pnlSub_Pannel.Tag = "NONE";
            // 
            // lblSub_Name
            // 
            this.lblSub_Name.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Name.ForeColor = System.Drawing.Color.White;
            this.lblSub_Name.Location = new System.Drawing.Point(12, 11);
            this.lblSub_Name.Name = "lblSub_Name";
            this.lblSub_Name.Size = new System.Drawing.Size(453, 21);
            this.lblSub_Name.TabIndex = 4;
            this.lblSub_Name.Text = "Product 001";
            // 
            // lblSub_Info
            // 
            this.lblSub_Info.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Info.AutoSize = true;
            this.lblSub_Info.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSub_Info.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Info.ForeColor = System.Drawing.Color.White;
            this.lblSub_Info.Location = new System.Drawing.Point(633, 14);
            this.lblSub_Info.Name = "lblSub_Info";
            this.lblSub_Info.Size = new System.Drawing.Size(109, 13);
            this.lblSub_Info.TabIndex = 3;
            this.lblSub_Info.Text = "Modify/Information";
            this.lblSub_Info.Click += new System.EventHandler(this.Info_Modif);
            // 
            // pcSub_Info
            // 
            this.pcSub_Info.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pcSub_Info.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcSub_Info.Image = ((System.Drawing.Image)(resources.GetObject("pcSub_Info.Image")));
            this.pcSub_Info.Location = new System.Drawing.Point(607, 8);
            this.pcSub_Info.Name = "pcSub_Info";
            this.pcSub_Info.Size = new System.Drawing.Size(20, 26);
            this.pcSub_Info.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcSub_Info.TabIndex = 2;
            this.pcSub_Info.TabStop = false;
            this.pcSub_Info.Click += new System.EventHandler(this.Info_Modif);
            // 
            // lblSub_Delete
            // 
            this.lblSub_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Delete.AutoSize = true;
            this.lblSub_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSub_Delete.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Delete.ForeColor = System.Drawing.Color.White;
            this.lblSub_Delete.Location = new System.Drawing.Point(504, 14);
            this.lblSub_Delete.Name = "lblSub_Delete";
            this.lblSub_Delete.Size = new System.Drawing.Size(82, 13);
            this.lblSub_Delete.TabIndex = 1;
            this.lblSub_Delete.Text = "Delete Product";
            this.lblSub_Delete.Click += new System.EventHandler(this.DeleteRecord);
            // 
            // pcSub_Delete
            // 
            this.pcSub_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pcSub_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcSub_Delete.Image = ((System.Drawing.Image)(resources.GetObject("pcSub_Delete.Image")));
            this.pcSub_Delete.Location = new System.Drawing.Point(478, 8);
            this.pcSub_Delete.Name = "pcSub_Delete";
            this.pcSub_Delete.Size = new System.Drawing.Size(20, 26);
            this.pcSub_Delete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcSub_Delete.TabIndex = 0;
            this.pcSub_Delete.TabStop = false;
            this.pcSub_Delete.Click += new System.EventHandler(this.DeleteRecord);
            // 
            // lblNoProduct
            // 
            this.lblNoProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNoProduct.AutoSize = true;
            this.lblNoProduct.Font = new System.Drawing.Font("Segoe UI", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblNoProduct.Location = new System.Drawing.Point(387, 208);
            this.lblNoProduct.Name = "lblNoProduct";
            this.lblNoProduct.Size = new System.Drawing.Size(233, 50);
            this.lblNoProduct.TabIndex = 28;
            this.lblNoProduct.Text = "No Products";
            // 
            // flpProduct
            // 
            this.flpProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpProduct.AutoScroll = true;
            this.flpProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpProduct.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpProduct.Location = new System.Drawing.Point(270, 49);
            this.flpProduct.Name = "flpProduct";
            this.flpProduct.Size = new System.Drawing.Size(467, 367);
            this.flpProduct.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(265, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 30);
            this.label2.TabIndex = 26;
            this.label2.Text = "Product :";
            // 
            // lblNoCategory
            // 
            this.lblNoCategory.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblNoCategory.AutoSize = true;
            this.lblNoCategory.Font = new System.Drawing.Font("Segoe UI", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblNoCategory.Location = new System.Drawing.Point(21, 207);
            this.lblNoCategory.Name = "lblNoCategory";
            this.lblNoCategory.Size = new System.Drawing.Size(239, 50);
            this.lblNoCategory.TabIndex = 24;
            this.lblNoCategory.Text = "No Category";
            // 
            // flpCategory
            // 
            this.flpCategory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.flpCategory.AutoScroll = true;
            this.flpCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpCategory.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpCategory.Location = new System.Drawing.Point(16, 48);
            this.flpCategory.Name = "flpCategory";
            this.flpCategory.Size = new System.Drawing.Size(248, 368);
            this.flpCategory.TabIndex = 23;
            this.flpCategory.WrapContents = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 30);
            this.label5.TabIndex = 22;
            this.label5.Text = "Category :";
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddProduct.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.Location = new System.Drawing.Point(674, 27);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(63, 23);
            this.btnAddProduct.TabIndex = 31;
            this.btnAddProduct.Text = "Add +";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBack.Location = new System.Drawing.Point(15, 432);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 32;
            this.btnBack.Text = "<< Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 465);
            this.Controls.Add(this.pnlSub_Pannel);
            this.Controls.Add(this.lblNoProduct);
            this.Controls.Add(this.flpProduct);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblNoCategory);
            this.Controls.Add(this.flpCategory);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.btnBack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmProduct";
            this.Text = "frmProduct";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlSub_Pannel.ResumeLayout(false);
            this.pnlSub_Pannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Info)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Delete)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSub_Pannel;
        private System.Windows.Forms.Label lblSub_Name;
        private System.Windows.Forms.Label lblSub_Info;
        private System.Windows.Forms.PictureBox pcSub_Info;
        private System.Windows.Forms.Label lblSub_Delete;
        private System.Windows.Forms.PictureBox pcSub_Delete;
        private System.Windows.Forms.Label lblNoProduct;
        private System.Windows.Forms.FlowLayoutPanel flpProduct;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNoCategory;
        private System.Windows.Forms.FlowLayoutPanel flpCategory;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnBack;
    }
}