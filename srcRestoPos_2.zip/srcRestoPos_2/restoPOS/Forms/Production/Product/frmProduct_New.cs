﻿/************************************************************************
	Filename 	 :	frmProduct_New.cs
	Created  	 :	01/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Form to add new product to the database
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using restoPOS.Commons;

namespace restoPOS.Forms.Production.Product
{
    public partial class frmProduct_New : Form
    {
        public delegate void AnnounceParentHandler();
        public event AnnounceParentHandler FormHidden;

        public delegate void UpdateAnnounceParentHandler(string strLabel);
        public event UpdateAnnounceParentHandler DataUpdated;

        public Category.frmCategoryNew newCategoryForm = new Category.frmCategoryNew();

        public frmProduct_New()
        {
            InitializeComponent();

            newCategoryForm.FormHidden += new Category.frmCategoryNew.AnnounceParentHandler(() =>
            {
                this.Show();
                Animation.FadeIn(this, 90, 5);
            });

            newCategoryForm.DataUpdated += new Category.frmCategoryNew.AnnounceParentHandler(() =>
            {
                PopulateCategoryList();
                cbNew_Category.Text = newCategoryForm.tbLabel;
            });

            PopulateCategoryList();
        }

        /// <summary>
        /// Hides the form and reset all fields to its original state</summary>
        /// <param name="fullHide">
        /// If true erase all fields</param>
        private void HideMe(bool fullHide = true)
        {
            if (fullHide)
                tbNew_Label.Text = tbNew_Desc.Text = tbNew_Tag.Text = cbNew_Category.Text = "";

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            FormHidden();
            Animation.FadeOut(this, 5);
        }

        /// <summary>
        /// Populates the combo box with a list of all categories</summary>
        private void PopulateCategoryList()
        {
            cbNew_Category.Items.Clear();

            Hashtable categories = Common.DoSqlQuery("SELECT Category_Label FROM Category", new short[] { 0 });
            foreach (DictionaryEntry row in categories)
                cbNew_Category.Items.Add(Convert.ToString(((Hashtable)row.Value)[0]));
        }

        private void btnNew_Cancel_Click(object sender, EventArgs e)
        {
            HideMe();
        }

        private void TBs_TextChanged(object sender, EventArgs e)
        {
            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            TextBox textbox = (TextBox)sender;

            if (textbox.Name.Equals("tbNew_Label"))
                Common.TextBoxIsValid(tbNew_Label, generalErrorToolTip, true, 30);
            if (textbox.Name.Equals("tbNew_Tag"))
                Common.TextBoxIsValid(tbNew_Tag, generalErrorToolTip, false, 30);
            if (textbox.Name.Equals("tbNew_Tax"))
            {
                Regex isDecimal = new Regex("^[0-9]{1,2}([.][0-9]{1,2})?$");

                if (tbNew_Tax.Text.Equals(""))
                    Common.ShowErrorToolTip(generalErrorToolTip, "Empty field", tbNew_Tax);
                else if (!isDecimal.IsMatch(tbNew_Tax.Text))
                    Common.ShowErrorToolTip(generalErrorToolTip, "Invalid tax format", tbNew_Tax);
            }
        }

        private void btnNew_OK_Click(object sender, EventArgs e)
        {
            try
            {
                // Field validations

                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();

                if (!Common.TextBoxIsValid(tbNew_Label, generalErrorToolTip, true, 30))
                    return;
                if (!Common.TextBoxIsValid(tbNew_Tag, generalErrorToolTip, false, 30))
                    return;

                Regex isDecimal = new Regex("^[0-9]{1,2}([.][0-9]{1,2})?$");
                if (tbNew_Tax.Text.Equals(""))
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "Empty field", tbNew_Tax);
                    return;
                }
                else if (!isDecimal.IsMatch(tbNew_Tax.Text))
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "Invalid tax format", tbNew_Tax);
                    return;
                }

                // Data(existence) validation

                if (!cbNew_Category.Text.Equals("") && !Common.ValueExistInTable("Category", "Category_Label = '" + cbNew_Category.Text + "'"))
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "The category does not exist", cbNew_Category);
                    return;
                }

                if (Common.ValueExistInTable("Product", "Product_Label = '" + tbNew_Label.Text + "'"))
                    Common.ShowErrorToolTip(generalErrorToolTip, "The product label already exist, please chose another", tbNew_Label);
                else
                {
                    int result;
                    if (cbNew_Category.Text.Equals(""))
                    {
                        result = Common.DoSqlNonQuery("INSERT INTO Product (Product_Label, Product_Description, Product_Barcode," +
                                             " Product_Tag,  Product_Tax) " + "VALUES ('" + tbNew_Label.Text + "', '" + tbNew_Desc.Text +
                                             "', '" + tbNew_Barcode.Text + "', '" + tbNew_Tag.Text + "', " + tbNew_Tax.Text + ")");
                    }
                    else
                    {
                        Hashtable tblCategory = Common.DoSqlQuery("SELECT Category_ID FROM Category WHERE Category_Label = '" + cbNew_Category.Text + "'", new short[] { 0 });

                        int categoryID = (int)(((Hashtable)tblCategory[0])[0]);
                        result = Common.DoSqlNonQuery("INSERT INTO Product (Product_Label, Product_Description, Product_Barcode," +
                                             " Product_Tag,  Product_Tax, Product_Category) " + "VALUES ('" + tbNew_Label.Text + "', '" +
                                             tbNew_Desc.Text + "', '" + tbNew_Barcode.Text + "', '" + tbNew_Tag.Text + "', " + tbNew_Tax.Text +
                                             ", " + categoryID + ")");
                    }

                    if (result == 0)
                        MessageBox.Show("An error occurred, records not affected", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        DataUpdated(cbNew_Category.Text);
                        HideMe();
                    }
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnNewCat_Click(object sender, EventArgs e)
        {
            HideMe(false);

            newCategoryForm.Show();
            newCategoryForm.Size = this.Size;
            newCategoryForm.Location = this.Location;
            newCategoryForm.TopMost = true;
            newCategoryForm.tbLabel = cbNew_Category.Text;
            Animation.FadeIn(newCategoryForm, 90, 5);
        }
    }
}
