﻿namespace restoPOS.Forms.Production.Product
{
    partial class frmProduct_InfoModif
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.generalErrorToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNewCat = new System.Windows.Forms.Button();
            this.cbNew_Category = new System.Windows.Forms.ComboBox();
            this.pcntTax = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbNew_Tax = new System.Windows.Forms.TextBox();
            this.tbNew_Barcode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNew_Label = new System.Windows.Forms.Label();
            this.btnUpdate_Cancel = new System.Windows.Forms.Button();
            this.tbNew_Desc = new System.Windows.Forms.TextBox();
            this.tbNew_Label = new System.Windows.Forms.TextBox();
            this.tbNew_Tag = new System.Windows.Forms.TextBox();
            this.btnUpdateModify = new System.Windows.Forms.Button();
            this.lblNew_Tag = new System.Windows.Forms.Label();
            this.lblNew_Desc = new System.Windows.Forms.Label();
            this.gbNew = new System.Windows.Forms.GroupBox();
            this.gbNew.SuspendLayout();
            this.SuspendLayout();
            // 
            // generalErrorToolTip
            // 
            this.generalErrorToolTip.IsBalloon = true;
            this.generalErrorToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.generalErrorToolTip.ToolTipTitle = "Error";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(6, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Product Label :";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.ForeColor = System.Drawing.Color.White;
            this.lblID.Location = new System.Drawing.Point(111, 21);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(23, 13);
            this.lblID.TabIndex = 16;
            this.lblID.Text = "001";
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.Black;
            this.btnBack.Location = new System.Drawing.Point(9, 352);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 15;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNewCat
            // 
            this.btnNewCat.Enabled = false;
            this.btnNewCat.ForeColor = System.Drawing.Color.Black;
            this.btnNewCat.Location = new System.Drawing.Point(343, 165);
            this.btnNewCat.Name = "btnNewCat";
            this.btnNewCat.Size = new System.Drawing.Size(22, 25);
            this.btnNewCat.TabIndex = 14;
            this.btnNewCat.Text = "+";
            this.btnNewCat.UseVisualStyleBackColor = true;
            this.btnNewCat.Click += new System.EventHandler(this.btnNewCat_Click);
            // 
            // cbNew_Category
            // 
            this.cbNew_Category.BackColor = System.Drawing.SystemColors.Control;
            this.cbNew_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.cbNew_Category.FormattingEnabled = true;
            this.cbNew_Category.Location = new System.Drawing.Point(114, 165);
            this.cbNew_Category.Name = "cbNew_Category";
            this.cbNew_Category.Size = new System.Drawing.Size(223, 25);
            this.cbNew_Category.TabIndex = 5;
            // 
            // pcntTax
            // 
            this.pcntTax.AutoSize = true;
            this.pcntTax.BackColor = System.Drawing.SystemColors.Control;
            this.pcntTax.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcntTax.ForeColor = System.Drawing.Color.Black;
            this.pcntTax.Location = new System.Drawing.Point(348, 109);
            this.pcntTax.Name = "pcntTax";
            this.pcntTax.Size = new System.Drawing.Size(16, 13);
            this.pcntTax.TabIndex = 13;
            this.pcntTax.Text = "%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(6, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Product Category :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Product Tax :";
            // 
            // tbNew_Tax
            // 
            this.tbNew_Tax.Location = new System.Drawing.Point(114, 103);
            this.tbNew_Tax.Name = "tbNew_Tax";
            this.tbNew_Tax.ReadOnly = true;
            this.tbNew_Tax.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Tax.TabIndex = 3;
            this.tbNew_Tax.Tag = "";
            this.tbNew_Tax.Text = "0.00";
            this.tbNew_Tax.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // tbNew_Barcode
            // 
            this.tbNew_Barcode.Location = new System.Drawing.Point(114, 134);
            this.tbNew_Barcode.Name = "tbNew_Barcode";
            this.tbNew_Barcode.ReadOnly = true;
            this.tbNew_Barcode.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Barcode.TabIndex = 4;
            this.tbNew_Barcode.Tag = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Product Barcode :";
            // 
            // lblNew_Label
            // 
            this.lblNew_Label.AutoSize = true;
            this.lblNew_Label.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Label.ForeColor = System.Drawing.Color.White;
            this.lblNew_Label.Location = new System.Drawing.Point(6, 47);
            this.lblNew_Label.Name = "lblNew_Label";
            this.lblNew_Label.Size = new System.Drawing.Size(82, 13);
            this.lblNew_Label.TabIndex = 0;
            this.lblNew_Label.Text = "Product Label :";
            // 
            // btnUpdate_Cancel
            // 
            this.btnUpdate_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnUpdate_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate_Cancel.ForeColor = System.Drawing.Color.Black;
            this.btnUpdate_Cancel.Location = new System.Drawing.Point(209, 352);
            this.btnUpdate_Cancel.Name = "btnUpdate_Cancel";
            this.btnUpdate_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate_Cancel.TabIndex = 8;
            this.btnUpdate_Cancel.Text = "Cancel";
            this.btnUpdate_Cancel.UseVisualStyleBackColor = true;
            this.btnUpdate_Cancel.Visible = false;
            this.btnUpdate_Cancel.Click += new System.EventHandler(this.btnUpdate_Cancel_Click);
            // 
            // tbNew_Desc
            // 
            this.tbNew_Desc.Location = new System.Drawing.Point(9, 215);
            this.tbNew_Desc.Multiline = true;
            this.tbNew_Desc.Name = "tbNew_Desc";
            this.tbNew_Desc.ReadOnly = true;
            this.tbNew_Desc.Size = new System.Drawing.Size(356, 128);
            this.tbNew_Desc.TabIndex = 6;
            this.tbNew_Desc.Tag = "";
            // 
            // tbNew_Label
            // 
            this.tbNew_Label.Location = new System.Drawing.Point(114, 41);
            this.tbNew_Label.Name = "tbNew_Label";
            this.tbNew_Label.ReadOnly = true;
            this.tbNew_Label.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Label.TabIndex = 1;
            this.tbNew_Label.Tag = "";
            this.tbNew_Label.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // tbNew_Tag
            // 
            this.tbNew_Tag.Location = new System.Drawing.Point(114, 72);
            this.tbNew_Tag.Name = "tbNew_Tag";
            this.tbNew_Tag.ReadOnly = true;
            this.tbNew_Tag.Size = new System.Drawing.Size(251, 25);
            this.tbNew_Tag.TabIndex = 2;
            this.tbNew_Tag.Tag = "";
            this.tbNew_Tag.TextChanged += new System.EventHandler(this.TBs_TextChanged);
            // 
            // btnUpdateModify
            // 
            this.btnUpdateModify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnUpdateModify.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateModify.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateModify.Location = new System.Drawing.Point(290, 352);
            this.btnUpdateModify.Name = "btnUpdateModify";
            this.btnUpdateModify.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateModify.TabIndex = 7;
            this.btnUpdateModify.Tag = "0";
            this.btnUpdateModify.Text = "Modify";
            this.btnUpdateModify.UseVisualStyleBackColor = true;
            this.btnUpdateModify.Click += new System.EventHandler(this.btnUpdateModify_Click);
            // 
            // lblNew_Tag
            // 
            this.lblNew_Tag.AutoSize = true;
            this.lblNew_Tag.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Tag.ForeColor = System.Drawing.Color.White;
            this.lblNew_Tag.Location = new System.Drawing.Point(6, 78);
            this.lblNew_Tag.Name = "lblNew_Tag";
            this.lblNew_Tag.Size = new System.Drawing.Size(73, 13);
            this.lblNew_Tag.TabIndex = 2;
            this.lblNew_Tag.Text = "Product Tag :";
            // 
            // lblNew_Desc
            // 
            this.lblNew_Desc.AutoSize = true;
            this.lblNew_Desc.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Desc.ForeColor = System.Drawing.Color.White;
            this.lblNew_Desc.Location = new System.Drawing.Point(6, 199);
            this.lblNew_Desc.Name = "lblNew_Desc";
            this.lblNew_Desc.Size = new System.Drawing.Size(121, 13);
            this.lblNew_Desc.TabIndex = 4;
            this.lblNew_Desc.Text = "Category Description :";
            // 
            // gbNew
            // 
            this.gbNew.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbNew.Controls.Add(this.label6);
            this.gbNew.Controls.Add(this.lblID);
            this.gbNew.Controls.Add(this.btnBack);
            this.gbNew.Controls.Add(this.btnNewCat);
            this.gbNew.Controls.Add(this.cbNew_Category);
            this.gbNew.Controls.Add(this.pcntTax);
            this.gbNew.Controls.Add(this.label3);
            this.gbNew.Controls.Add(this.label1);
            this.gbNew.Controls.Add(this.tbNew_Tax);
            this.gbNew.Controls.Add(this.tbNew_Barcode);
            this.gbNew.Controls.Add(this.label2);
            this.gbNew.Controls.Add(this.lblNew_Label);
            this.gbNew.Controls.Add(this.btnUpdate_Cancel);
            this.gbNew.Controls.Add(this.tbNew_Desc);
            this.gbNew.Controls.Add(this.tbNew_Label);
            this.gbNew.Controls.Add(this.tbNew_Tag);
            this.gbNew.Controls.Add(this.btnUpdateModify);
            this.gbNew.Controls.Add(this.lblNew_Tag);
            this.gbNew.Controls.Add(this.lblNew_Desc);
            this.gbNew.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbNew.ForeColor = System.Drawing.Color.White;
            this.gbNew.Location = new System.Drawing.Point(26, 21);
            this.gbNew.Name = "gbNew";
            this.gbNew.Size = new System.Drawing.Size(376, 381);
            this.gbNew.TabIndex = 11;
            this.gbNew.TabStop = false;
            this.gbNew.Text = "View/Modify Product";
            // 
            // frmProduct_InfoModif
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(429, 423);
            this.Controls.Add(this.gbNew);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmProduct_InfoModif";
            this.Opacity = 0D;
            this.ShowInTaskbar = false;
            this.Text = "frmProduct_InfoModif";
            this.TopMost = true;
            this.gbNew.ResumeLayout(false);
            this.gbNew.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip generalErrorToolTip;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNewCat;
        private System.Windows.Forms.ComboBox cbNew_Category;
        private System.Windows.Forms.Label pcntTax;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNew_Tax;
        private System.Windows.Forms.TextBox tbNew_Barcode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNew_Label;
        private System.Windows.Forms.Button btnUpdate_Cancel;
        private System.Windows.Forms.TextBox tbNew_Desc;
        private System.Windows.Forms.TextBox tbNew_Label;
        private System.Windows.Forms.TextBox tbNew_Tag;
        private System.Windows.Forms.Button btnUpdateModify;
        private System.Windows.Forms.Label lblNew_Tag;
        private System.Windows.Forms.Label lblNew_Desc;
        private System.Windows.Forms.GroupBox gbNew;
    }
}