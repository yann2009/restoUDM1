﻿/************************************************************************
	Filename 	 :	frmProduct.cs
	Created  	 :	30/9/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Main product form
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;

namespace restoPOS.Forms.Production.Product
{
    public partial class frmProduct : Form
    {
        private bool subPanel_isHidden = false;
        private string selectedProductID = "NONE";
        private string selectedProductLabel = "";
        private string selectedCategoryID = "ALL";

        public Product.frmProduct_New newProductForm = new Product.frmProduct_New();
        public Product.frmProduct_InfoModif imProductForm = new Product.frmProduct_InfoModif();

        /// <summary>
        /// Selects the label specified in the category panel</summary>
        /// <param name="categoryLabel">
        /// Label to select</param>
        public void SelectCategoryItem(string categoryLabel)
        {
            if (flpCategory.Controls.Count > 0)
            {
                Button flpCatBtn = (Button)flpCategory.Controls[("flpCategory_Label_" + categoryLabel)];
                EventArgs e = new EventArgs();
                flpCategoryControl_Click(flpCatBtn, e);
                flpCatBtn.Select();
            }
        }

        /// <summary>
        /// Selects the label specified in the product panel</summary>
        /// <param name="productLabel">
        /// Label to select</param>
        public void SelectProductItem(string productLabel)
        {
            if (flpProduct.Controls.Count > 0)
            {
                Button flpProdBtn = (Button)flpProduct.Controls[("flpControl_Label_" + productLabel)];
                EventArgs e = new EventArgs();
                flpProductControl_Click(flpProdBtn, e);
                flpProdBtn.Select();
            }
        }

        public frmProduct()
        {
            InitializeComponent();
            newProductForm.DataUpdated += new Product.frmProduct_New.UpdateAnnounceParentHandler(UpdateReceived);
            newProductForm.FormHidden += new Product.frmProduct_New.AnnounceParentHandler(() => { });

            imProductForm.DataUpdated += new Product.frmProduct_InfoModif.UpdateAnnounceParentHandler(UpdateReceived);
            imProductForm.FormHidden += new Product.frmProduct_InfoModif.AnnounceParentHandler(() => { });

            Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5, 0);
            PopulateCategories();
            PopulateProducts("ALL");
        }

        /// <summary>
        /// Method raised when update is required</summary>
        private void UpdateReceived(string strLabel)
        {
            if (strLabel.Equals(""))
                PopulateProducts(selectedCategoryID);
            else
            {
                PopulateCategories();
                SelectCategoryItem(strLabel);
            }
        }

        /// <summary>
        /// Populates the Category list</summary>
        public void PopulateCategories()
        {
            try
            {
                flpCategory.Controls.Clear();

                // Adds to default buttons for all category products and for uncategorized products
                Button controlButton_All = new Button();
                controlButton_All.BackColor = System.Drawing.Color.Gray;
                controlButton_All.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                controlButton_All.Width = 208;
                controlButton_All.Name = "flpCategory_All";
                controlButton_All.Tag = "ALL";
                controlButton_All.Text = "Any Category";
                controlButton_All.Click += new EventHandler(flpCategoryControl_Click);

                Button controlButton_UC = new Button();
                controlButton_UC.BackColor = System.Drawing.Color.Gray;
                controlButton_UC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                controlButton_UC.Width = 208;
                controlButton_UC.Name = "flpCategory_UC";
                controlButton_UC.Tag = "UC";
                controlButton_UC.Text = "Uncategorized";
                controlButton_UC.Click += new EventHandler(flpCategoryControl_Click);

                flpCategory.Controls.Add(controlButton_All);
                flpCategory.Controls.Add(controlButton_UC);

                Hashtable categoryInfo = Common.DoSqlQuery("SELECT Category_ID, Category_Label FROM Category " + "ORDER BY Category_Label DESC", new short[] { 0, 1 });
                foreach (DictionaryEntry row in categoryInfo)
                {
                    Button controlButton = new Button();
                    controlButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                    controlButton.Name = "flpCategory_Label_" + Convert.ToString(((Hashtable)row.Value)[1]);   // Category_Label
                    controlButton.Width = 208;
                    controlButton.Tag = Convert.ToString(((Hashtable)row.Value)[0]);   // Category_ID
                    controlButton.Text = Convert.ToString(((Hashtable)row.Value)[1]);   // Category_Label
                    controlButton.Click += new EventHandler(flpCategoryControl_Click);

                    flpCategory.Controls.Add(controlButton);
                }

                if (flpCategory.Controls.Count == 0)
                    lblNoCategory.Visible = true;
                else
                    lblNoCategory.Visible = false;
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Populates the Product list</summary>
        /// <param name="categoryID">
        /// The category ID in which the product belongs</param>
        public void PopulateProducts(string categoryID)
        {
            try
            {
                flpProduct.Controls.Clear();

                string sqlQuery = "SELECT Product_ID, Product_Label FROM Product ";

                if (categoryID.Equals("UC"))
                    sqlQuery += "WHERE Product_Category IS NULL";
                else if (!categoryID.Equals("ALL"))
                    sqlQuery += "WHERE Product_Category = " + categoryID;

                sqlQuery += " ORDER BY Product_Label DESC";

                Hashtable categoryInfo = Common.DoSqlQuery(sqlQuery, new short[] { 0, 1 });
                foreach (DictionaryEntry row in categoryInfo)
                {
                    Button controlButton = new Button();
                    controlButton.Name = "flpControl_Label_" + Convert.ToString(((Hashtable)row.Value)[1]);   //Product_Label
                    controlButton.Tag = Convert.ToString(((Hashtable)row.Value)[0]);    //Product_ID
                    controlButton.Text = Convert.ToString(((Hashtable)row.Value)[1]);   //Product_Label
                    controlButton.AutoSize = true;
                    controlButton.Click += new EventHandler(flpProductControl_Click);

                    flpProduct.Controls.Add(controlButton);
                }

                if (flpProduct.Controls.Count == 0)
                    lblNoProduct.Visible = true;
                else
                    lblNoProduct.Visible = false;
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Handles the click event of flpCategorys' controls</summary>
        private void flpCategoryControl_Click(object sender, EventArgs e)
        {
            Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
            selectedCategoryID = ((Button)sender).Tag.ToString();
            PopulateProducts(((Button)sender).Tag.ToString());
        }

        /// <summary>
        /// Handles the click event of flpProducts' controls</summary>
        private void flpProductControl_Click(object sender, EventArgs e)
        {
            selectedProductID = ((Button)sender).Tag.ToString();
            selectedProductLabel = ((Button)sender).Text;
            string subPanel = pnlSub_Pannel.Tag.ToString();

            if (!subPanel.Equals("NONE") && !subPanel.Equals(selectedProductID) && !subPanel_isHidden)
            {
                Animation.AnimationToggle(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5, 0);
                pnlSub_Pannel.Tag = selectedProductID;
                lblSub_Name.Text = selectedProductLabel;
                Animation.AnimationToggle(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
            }
            else
            {
                pnlSub_Pannel.Tag = selectedProductID;
                lblSub_Name.Text = selectedProductLabel;
                Animation.AnimationToggle(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
            }
        }

        /// <summary>
        /// Method to delete records in the product context</summary>
        private void DeleteRecord(object sender, EventArgs e)
        {
            try
            {
                if (Common.DeleteRecord("Are you sure you want to delete the '" + selectedProductLabel + "' product? This action cannot be undone ",
                                        "Delete product", "DELETE FROM Product WHERE Product_ID = " + selectedProductID + ";"))
                {
                    Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);
                    PopulateCategories();
                    PopulateProducts(selectedCategoryID);
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);

            newProductForm.Show();
            newProductForm.Size = this.Size;
            newProductForm.Location = this.Location;
            newProductForm.TopMost = true;
            Animation.FadeIn(newProductForm, 90, 5);
        }

        private void Info_Modif(object sender, EventArgs e)
        {
            Animation.AnimationHide(pnlSub_Pannel, "Top", pnlSub_Pannel.Height, ref subPanel_isHidden, -5);

            imProductForm.ProductID = selectedProductID;
            imProductForm.Show();
            imProductForm.Size = this.Size;
            imProductForm.Location = this.Location;
            imProductForm.TopMost = true;
            Animation.FadeIn(imProductForm, 90, 5);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
