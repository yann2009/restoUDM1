﻿/************************************************************************
	Filename 	 :	Animation.cs
	Created  	 :	15/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Background login form
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using restoPOS.Commons;

namespace restoPOS.Forms.Login_Forms
{
    public partial class frmForeground : Form
    {
        private bool isPnlHidden = false;

        public Login_Forms.frmBackground parentForm;

        public void ShowMe()
        {
            this.Show();
            parentForm.Show();
        }

        public frmForeground()
        {
            InitializeComponent();

            ucNumKeypad.NumKeypadKeyPressed +=
                new Commons.UserControls.Keypads.ucNumKeypad.NumKeypadKeyPressedHandler(ucNumKeypad_NumKeyPressed);
            ucNumKeypad.ClearKeyPressed +=
                new Commons.UserControls.Keypads.ucNumKeypad.ClearKeyPressedHandler(ucNumKeypad_ClearKeyPressed);
            ucNumKeypad.GoKeyPressed +=
                new Commons.UserControls.Keypads.ucNumKeypad.GoKeyPressedHandler(ucNumKeypad_GoKeyPressed);

            Animation.AnimationHide(pnlError, "Top", pnlError.Height - 2, ref isPnlHidden, -2, 0);
        }

        private void ucNumKeypad_NumKeyPressed(string keyValue)
        {
            Animation.AnimationHide(pnlError, "Top", pnlError.Height - 2, ref isPnlHidden, -2, 0);
            tbPin.Text += keyValue;
        }

        private void ucNumKeypad_ClearKeyPressed()
        {
            tbPin.Text = "";
        }

        private void ucNumKeypad_GoKeyPressed()
        {

            if (tbPin.Text.Equals("1234"))
            {
                Animation.AnimationHide(pnlError, "Top", pnlError.Height - 2, ref isPnlHidden, -2, 0);
                restoPOS.Forms.Interfaces.MainMenu.Menu mn = new restoPOS.Forms.Interfaces.MainMenu.Menu();
                mn.parentForm = this;
                mn.Show();
                this.Hide();
                parentForm.Hide();
                tbPin.Text = " ";
            }
            else if (tbPin.Text.Equals(""))
            {
                lblError.Text = "Empty Field";
                Animation.AnimationShow(pnlError, "Top", pnlError.Height - 2, ref isPnlHidden, -2, 0);
            }
            else
            {
                lblError.Text = "Invalid PIN";
                Animation.AnimationShow(pnlError, "Top", pnlError.Height - 2, ref isPnlHidden, -2, 0);
            }
        }

        private void frmForeground_FormClosed(object sender, FormClosedEventArgs e)
        {
            parentForm.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ucNumKeypad_Load(object sender, EventArgs e)
        {
            ucNumKeypad.GoButtonEnable = true;
        }
    }
}
