﻿/************************************************************************
	Filename 	 :	Animation.cs
	Created  	 :	17/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Foreground login form
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using restoPOS.Commons;

namespace restoPOS.Forms.Login_Forms
{
    public partial class frmBackground : Form
    {
        public Login_Forms.frmForeground frmFG = new Login_Forms.frmForeground();
        public frmBackground()
        {
            InitializeComponent();
            frmFG.parentForm = this;

            frmFG.Show();
            frmFG.TopMost = true;
            Animation.FadeIn(frmFG, 85, 5);
        }
    }
}
