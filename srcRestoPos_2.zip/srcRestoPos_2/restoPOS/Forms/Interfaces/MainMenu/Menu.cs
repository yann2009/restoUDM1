﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace restoPOS.Forms.Interfaces.MainMenu
{
    public partial class Menu : Form
    {
        public restoPOS.Forms.Login_Forms.frmForeground parentForm;

        public Menu()
        {
            InitializeComponent();

            label3.Text = DateTime.Now.ToShortTimeString();
            label4.Text = DateTime.Now.ToShortDateString();
        }

        private void timeTimer_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToShortTimeString();
            label4.Text = DateTime.Now.ToShortDateString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Forms.Sale.Table.frmTable frm4= new Forms.Sale.Table.frmTable();
            frm4.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Forms.Sale.frmCheckout frmChk = new Forms.Sale.frmCheckout();
            frmChk.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            restoPOS.Forms.Production.Product.frmProduct frmProd = new restoPOS.Forms.Production.Product.frmProduct();
            frmProd.Show();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //restoPOS.Forms.Production.frmInvProd frmInv = new restoPOS.Forms.Production.frmInvProd();
            //frmInv.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            parentForm.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            parentForm.ShowMe();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Forms.Production.Product.frmProduct frm = new Forms.Production.Product.frmProduct();
            frm.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Forms.Production.Category.frmCategory frm2 = new Forms.Production.Category.frmCategory();
            frm2.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Forms.Sale.Client.frmClient frm3 = new Forms.Sale.Client.frmClient();
            frm3.Show();
        }
    }
}
