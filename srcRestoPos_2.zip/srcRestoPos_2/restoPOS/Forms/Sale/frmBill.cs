﻿/**
 * Billing form
 * by Y A Jaunky
 * 28.10.2013
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;

namespace restoPOS.Forms.Sale
{
    public partial class frmBill : Form
    {
               
        public frmBill()
        {
            InitializeComponent();        
           
        }

        private void frmBill_Load(object sender, EventArgs e)
        {
          
                       
        }
         private void btn_clear_Click(object sender, EventArgs e)
        {
             //code for backscape button
            if (txtpad.Text.Length > 0)
            {
                txtpad.Text = txtpad.Text.Substring(0, txtpad.Text.Length - 1);
            }
        }
        
        
        

        private void billingKeypad1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Cash_Click(object sender, EventArgs e)
        {
            //still need to be related to db
            float value = float.Parse(txtVal.Text);
            float key = float.Parse(txtpad.Text);

            float change = key - value;
            lblChange.BackColor = Color.Yellow;
            lblChange.Font = new Font(lblChange.Font.FontFamily, 30);
            lblChange.Text = ("Change due = " + change);

        }

        private void cmdCredit_Click(object sender, EventArgs e)
        {
            //still need to be related to db
            float value = float.Parse(txtVal.Text);
            float key = float.Parse(txtpad.Text);

            float change = key - value;
            lblChange.BackColor = Color.Yellow;
            lblChange.Font = new Font(lblChange.Font.FontFamily, 30);
            lblChange.Text = ("Change due = " + change);
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            txtpad.Text += "1";
        }

        private void btn_10_Click(object sender, EventArgs e)
        {
             txtpad.Text += "10";
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            txtpad.Text += "2";
        }

        private void bnt_3_Click(object sender, EventArgs e)
        {
            txtpad.Text += "3";
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            txtpad.Text += "4";
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            txtpad.Text += "5";
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            txtpad.Text += "6";
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            txtpad.Text += "7";
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            txtpad.Text += "8";
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            txtpad.Text += "9";
        }

        private void btn_00_Click(object sender, EventArgs e)
        {
            txtpad.Text += "00";
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            txtpad.Text += "0";
        }

        private void btn_dot_Click(object sender, EventArgs e)
        {
            txtpad.Text += ".";
        }

        private void btn_half_Click(object sender, EventArgs e)
        {
            txtpad.Text += "0.5";
        }

        private void btn_third_Click(object sender, EventArgs e)
        {
            txtpad.Text += "0.33";
        }

        private void btn_quarter_Click(object sender, EventArgs e)
        {
            txtpad.Text += "0.25";
        }

        private void btn_25_Click(object sender, EventArgs e)
        {
            txtpad.Text += "25";
        }

        private void btn_50_Click(object sender, EventArgs e)
        {
            txtpad.Text += "50";
        }

        private void btn_100_Click(object sender, EventArgs e)
        {
            txtpad.Text += "100";
        }

        private void btn_clear_Click_1(object sender, EventArgs e)
        {
            //backspace button
            if (txtpad.Text.Length > 0)
            {
                txtpad.Text = txtpad.Text.Substring(0, txtpad.Text.Length - 1);
            }
        }

        //Validation for entry in textbox
        public void numwithdecitxtBox_TxtChng(TextBox seltxt, object sender, EventArgs e)
        {
            // handle this event to clear the textbox if data pasted is not in the right format
            double tmp;
            if (!double.TryParse(seltxt.Text, out tmp))
            {
                seltxt.Clear();
                lblChange.BackColor = Color.Red;
                lblChange.Font = new Font(lblChange.Font.FontFamily, 30);
                lblChange.Text = "ERROR!!! Incorrect number format";

            }
            
        }

        public double val
        {
            get { return Convert.ToDouble(txtVal.Text); }
            set { txtVal.Text = Convert.ToString(value); }
        }
        private void txtpad_TextChanged(object sender, EventArgs e)
        {
            //validates entry
            numwithdecitxtBox_TxtChng(txtpad, sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //copies the value of txtVal to txtpad
            txtpad.Text = txtVal.Text;
                        
        }

        private void txtVal_TextChanged(object sender, EventArgs e)
        {
            //the value of txtVal appears on this button
            cmdVal.Text=txtVal.Text;
        }

        private void cmdRound_Click(object sender, EventArgs e)
        {
            //need still to be coded
        }

        private void cmdVal_Click(object sender, EventArgs e)
        {
            //copies the value of txtVal to txtpad
            txtpad.Text = txtVal.Text;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

       
        
    }
}
