﻿namespace restoPOS.Forms.Sale
{
    partial class frmCheckout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCheckout));
            this.lsItems = new System.Windows.Forms.ListBox();
            this.flPnlCategory = new System.Windows.Forms.FlowLayoutPanel();
            this.btnDrinks = new System.Windows.Forms.Button();
            this.btnSndwch = new System.Windows.Forms.Button();
            this.btnCoff = new System.Windows.Forms.Button();
            this.flPnlProduct = new System.Windows.Forms.FlowLayoutPanel();
            this.coke = new System.Windows.Forms.Button();
            this.sprite = new System.Windows.Forms.Button();
            this.gBeer = new System.Windows.Forms.Button();
            this.taco = new System.Windows.Forms.Button();
            this.vWrap = new System.Windows.Forms.Button();
            this.capp = new System.Windows.Forms.Button();
            this.latte = new System.Windows.Forms.Button();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.btnSettle = new System.Windows.Forms.Button();
            this.btnBackspace = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ucNumKeypad1 = new restoPOS.Commons.UserControls.Keypads.ucNumKeypad();
            this.lbPrix = new System.Windows.Forms.ListBox();
            this.flPnlCategory.SuspendLayout();
            this.flPnlProduct.SuspendLayout();
            this.SuspendLayout();
            // 
            // lsItems
            // 
            this.lsItems.BackColor = System.Drawing.Color.White;
            this.lsItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lsItems.FormattingEnabled = true;
            this.lsItems.ItemHeight = 16;
            this.lsItems.Location = new System.Drawing.Point(16, 15);
            this.lsItems.Margin = new System.Windows.Forms.Padding(4);
            this.lsItems.Name = "lsItems";
            this.lsItems.Size = new System.Drawing.Size(488, 720);
            this.lsItems.TabIndex = 2;
            this.lsItems.SelectedIndexChanged += new System.EventHandler(this.lsItems_SelectedIndexChanged);
            // 
            // flPnlCategory
            // 
            this.flPnlCategory.Controls.Add(this.btnDrinks);
            this.flPnlCategory.Controls.Add(this.btnSndwch);
            this.flPnlCategory.Controls.Add(this.btnCoff);
            this.flPnlCategory.Location = new System.Drawing.Point(513, 15);
            this.flPnlCategory.Margin = new System.Windows.Forms.Padding(4);
            this.flPnlCategory.Name = "flPnlCategory";
            this.flPnlCategory.Size = new System.Drawing.Size(245, 521);
            this.flPnlCategory.TabIndex = 3;
            this.flPnlCategory.Paint += new System.Windows.Forms.PaintEventHandler(this.flPnlCategory_Paint);
            // 
            // btnDrinks
            // 
            this.btnDrinks.BackColor = System.Drawing.Color.Gold;
            this.btnDrinks.FlatAppearance.BorderSize = 0;
            this.btnDrinks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDrinks.Image = global::restoPOS.Properties.Resources.coctail_48;
            this.btnDrinks.Location = new System.Drawing.Point(3, 3);
            this.btnDrinks.Name = "btnDrinks";
            this.btnDrinks.Size = new System.Drawing.Size(242, 88);
            this.btnDrinks.TabIndex = 0;
            this.btnDrinks.UseVisualStyleBackColor = false;
            this.btnDrinks.Click += new System.EventHandler(this.btnDrinks_Click);
            // 
            // btnSndwch
            // 
            this.btnSndwch.BackColor = System.Drawing.Color.LimeGreen;
            this.btnSndwch.FlatAppearance.BorderSize = 0;
            this.btnSndwch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSndwch.Image = global::restoPOS.Properties.Resources.taco_48;
            this.btnSndwch.Location = new System.Drawing.Point(3, 97);
            this.btnSndwch.Name = "btnSndwch";
            this.btnSndwch.Size = new System.Drawing.Size(242, 88);
            this.btnSndwch.TabIndex = 1;
            this.btnSndwch.UseVisualStyleBackColor = false;
            this.btnSndwch.Click += new System.EventHandler(this.btnSndwch_Click);
            // 
            // btnCoff
            // 
            this.btnCoff.BackColor = System.Drawing.Color.Chocolate;
            this.btnCoff.FlatAppearance.BorderSize = 0;
            this.btnCoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCoff.Image = global::restoPOS.Properties.Resources.hot_chocolate_48;
            this.btnCoff.Location = new System.Drawing.Point(3, 191);
            this.btnCoff.Name = "btnCoff";
            this.btnCoff.Size = new System.Drawing.Size(242, 88);
            this.btnCoff.TabIndex = 2;
            this.btnCoff.UseVisualStyleBackColor = false;
            this.btnCoff.Click += new System.EventHandler(this.btnCoff_Click);
            // 
            // flPnlProduct
            // 
            this.flPnlProduct.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flPnlProduct.Controls.Add(this.coke);
            this.flPnlProduct.Controls.Add(this.sprite);
            this.flPnlProduct.Controls.Add(this.gBeer);
            this.flPnlProduct.Controls.Add(this.taco);
            this.flPnlProduct.Controls.Add(this.vWrap);
            this.flPnlProduct.Controls.Add(this.capp);
            this.flPnlProduct.Controls.Add(this.latte);
            this.flPnlProduct.Location = new System.Drawing.Point(765, 15);
            this.flPnlProduct.Margin = new System.Windows.Forms.Padding(4);
            this.flPnlProduct.Name = "flPnlProduct";
            this.flPnlProduct.Size = new System.Drawing.Size(584, 887);
            this.flPnlProduct.TabIndex = 4;
            this.flPnlProduct.Paint += new System.Windows.Forms.PaintEventHandler(this.flPnlProduct_Paint);
            // 
            // coke
            // 
            this.coke.BackColor = System.Drawing.Color.Gold;
            this.coke.FlatAppearance.BorderSize = 0;
            this.coke.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.coke.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coke.ForeColor = System.Drawing.Color.White;
            this.coke.Location = new System.Drawing.Point(3, 3);
            this.coke.Name = "coke";
            this.coke.Size = new System.Drawing.Size(242, 88);
            this.coke.TabIndex = 1;
            this.coke.Tag = "20";
            this.coke.Text = "Coke";
            this.coke.UseVisualStyleBackColor = false;
            this.coke.Visible = false;
            this.coke.Click += new System.EventHandler(this.item_Click);
            // 
            // sprite
            // 
            this.sprite.BackColor = System.Drawing.Color.Gold;
            this.sprite.FlatAppearance.BorderSize = 0;
            this.sprite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sprite.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sprite.ForeColor = System.Drawing.Color.White;
            this.sprite.Location = new System.Drawing.Point(251, 3);
            this.sprite.Name = "sprite";
            this.sprite.Size = new System.Drawing.Size(242, 88);
            this.sprite.TabIndex = 2;
            this.sprite.Tag = "20";
            this.sprite.Text = "Sprite";
            this.sprite.UseVisualStyleBackColor = false;
            this.sprite.Visible = false;
            this.sprite.Click += new System.EventHandler(this.item_Click);
            // 
            // gBeer
            // 
            this.gBeer.BackColor = System.Drawing.Color.Gold;
            this.gBeer.FlatAppearance.BorderSize = 0;
            this.gBeer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gBeer.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gBeer.ForeColor = System.Drawing.Color.White;
            this.gBeer.Location = new System.Drawing.Point(3, 97);
            this.gBeer.Name = "gBeer";
            this.gBeer.Size = new System.Drawing.Size(242, 88);
            this.gBeer.TabIndex = 3;
            this.gBeer.Tag = "25";
            this.gBeer.Text = "Ginger Beer";
            this.gBeer.UseVisualStyleBackColor = false;
            this.gBeer.Visible = false;
            this.gBeer.Click += new System.EventHandler(this.item_Click);
            // 
            // taco
            // 
            this.taco.BackColor = System.Drawing.Color.LimeGreen;
            this.taco.FlatAppearance.BorderSize = 0;
            this.taco.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.taco.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taco.ForeColor = System.Drawing.Color.White;
            this.taco.Location = new System.Drawing.Point(251, 97);
            this.taco.Name = "taco";
            this.taco.Size = new System.Drawing.Size(242, 88);
            this.taco.TabIndex = 4;
            this.taco.Tag = "10";
            this.taco.Text = "Taco";
            this.taco.UseVisualStyleBackColor = false;
            this.taco.Visible = false;
            this.taco.Click += new System.EventHandler(this.item_Click);
            // 
            // vWrap
            // 
            this.vWrap.BackColor = System.Drawing.Color.LimeGreen;
            this.vWrap.FlatAppearance.BorderSize = 0;
            this.vWrap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vWrap.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vWrap.ForeColor = System.Drawing.Color.White;
            this.vWrap.Location = new System.Drawing.Point(3, 191);
            this.vWrap.Name = "vWrap";
            this.vWrap.Size = new System.Drawing.Size(242, 88);
            this.vWrap.TabIndex = 5;
            this.vWrap.Tag = "15";
            this.vWrap.Text = "Veg Wrap";
            this.vWrap.UseVisualStyleBackColor = false;
            this.vWrap.Visible = false;
            this.vWrap.Click += new System.EventHandler(this.item_Click);
            // 
            // capp
            // 
            this.capp.BackColor = System.Drawing.Color.Chocolate;
            this.capp.FlatAppearance.BorderSize = 0;
            this.capp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.capp.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capp.ForeColor = System.Drawing.Color.White;
            this.capp.Location = new System.Drawing.Point(251, 191);
            this.capp.Name = "capp";
            this.capp.Size = new System.Drawing.Size(242, 88);
            this.capp.TabIndex = 6;
            this.capp.Tag = "30";
            this.capp.Text = "Cappucino";
            this.capp.UseVisualStyleBackColor = false;
            this.capp.Visible = false;
            this.capp.Click += new System.EventHandler(this.item_Click);
            // 
            // latte
            // 
            this.latte.BackColor = System.Drawing.Color.Chocolate;
            this.latte.FlatAppearance.BorderSize = 0;
            this.latte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.latte.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.latte.ForeColor = System.Drawing.Color.White;
            this.latte.Location = new System.Drawing.Point(3, 285);
            this.latte.Name = "latte";
            this.latte.Size = new System.Drawing.Size(242, 88);
            this.latte.TabIndex = 7;
            this.latte.Tag = "50";
            this.latte.Text = "Latte";
            this.latte.UseVisualStyleBackColor = false;
            this.latte.Visible = false;
            this.latte.Click += new System.EventHandler(this.item_Click);
            // 
            // txtAmount
            // 
            this.txtAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAmount.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(513, 564);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(4);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.ReadOnly = true;
            this.txtAmount.Size = new System.Drawing.Size(165, 54);
            this.txtAmount.TabIndex = 5;
            this.txtAmount.Text = "1";
            this.txtAmount.TextChanged += new System.EventHandler(this.txtAmount_TextChanged);
            // 
            // btnSettle
            // 
            this.btnSettle.FlatAppearance.BorderSize = 0;
            this.btnSettle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LimeGreen;
            this.btnSettle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettle.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettle.Location = new System.Drawing.Point(61, 742);
            this.btnSettle.Margin = new System.Windows.Forms.Padding(4);
            this.btnSettle.Name = "btnSettle";
            this.btnSettle.Size = new System.Drawing.Size(296, 80);
            this.btnSettle.TabIndex = 8;
            this.btnSettle.Text = " SETTLE";
            this.btnSettle.UseVisualStyleBackColor = true;
            this.btnSettle.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBackspace
            // 
            this.btnBackspace.BackColor = System.Drawing.Color.White;
            this.btnBackspace.FlatAppearance.BorderSize = 0;
            this.btnBackspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackspace.Image = global::restoPOS.Properties.Resources.backspace_48;
            this.btnBackspace.Location = new System.Drawing.Point(687, 571);
            this.btnBackspace.Margin = new System.Windows.Forms.Padding(4);
            this.btnBackspace.Name = "btnBackspace";
            this.btnBackspace.Size = new System.Drawing.Size(65, 38);
            this.btnBackspace.TabIndex = 7;
            this.btnBackspace.UseVisualStyleBackColor = false;
            this.btnBackspace.Click += new System.EventHandler(this.btnBackspace_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Image = global::restoPOS.Properties.Resources.undo_48;
            this.btnBack.Location = new System.Drawing.Point(16, 883);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(64, 49);
            this.btnBack.TabIndex = 0;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(513, 540);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Quantity:";
            // 
            // ucNumKeypad1
            // 
            this.ucNumKeypad1.BackColor = System.Drawing.Color.White;
            this.ucNumKeypad1.GoButtonEnable = false;
            this.ucNumKeypad1.Location = new System.Drawing.Point(512, 623);
            this.ucNumKeypad1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ucNumKeypad1.Name = "ucNumKeypad1";
            this.ucNumKeypad1.Size = new System.Drawing.Size(245, 279);
            this.ucNumKeypad1.TabIndex = 6;
            this.ucNumKeypad1.Load += new System.EventHandler(this.ucNumKeypad1_Load);
            // 
            // lbPrix
            // 
            this.lbPrix.BackColor = System.Drawing.Color.White;
            this.lbPrix.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbPrix.FormattingEnabled = true;
            this.lbPrix.ItemHeight = 16;
            this.lbPrix.Location = new System.Drawing.Point(278, 13);
            this.lbPrix.Margin = new System.Windows.Forms.Padding(4);
            this.lbPrix.Name = "lbPrix";
            this.lbPrix.Size = new System.Drawing.Size(226, 720);
            this.lbPrix.TabIndex = 10;
            // 
            // frmCheckout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1302, 945);
            this.Controls.Add(this.lbPrix);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSettle);
            this.Controls.Add(this.btnBackspace);
            this.Controls.Add(this.ucNumKeypad1);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.flPnlProduct);
            this.Controls.Add(this.flPnlCategory);
            this.Controls.Add(this.lsItems);
            this.Controls.Add(this.btnBack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmCheckout";
            this.Text = "frmCheckout";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmCheckout_Load);
            this.flPnlCategory.ResumeLayout(false);
            this.flPnlProduct.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ListBox lsItems;
        private System.Windows.Forms.FlowLayoutPanel flPnlCategory;
        private System.Windows.Forms.FlowLayoutPanel flPnlProduct;
        private System.Windows.Forms.TextBox txtAmount;
        private Commons.UserControls.Keypads.ucNumKeypad ucNumKeypad1;
        private System.Windows.Forms.Button btnBackspace;
        private System.Windows.Forms.Button btnSettle;
        private System.Windows.Forms.Button btnDrinks;
        private System.Windows.Forms.Button btnSndwch;
        private System.Windows.Forms.Button btnCoff;
        private System.Windows.Forms.Button coke;
        private System.Windows.Forms.Button sprite;
        private System.Windows.Forms.Button gBeer;
        private System.Windows.Forms.Button taco;
        private System.Windows.Forms.Button vWrap;
        private System.Windows.Forms.Button capp;
        private System.Windows.Forms.Button latte;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbPrix;
    }
}