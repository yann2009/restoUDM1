﻿namespace restoPOS.Forms.Sale
{
    partial class frmBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtVal = new System.Windows.Forms.TextBox();
            this.txtpad = new System.Windows.Forms.TextBox();
            this.cmdCash = new System.Windows.Forms.Button();
            this.cmdCredit = new System.Windows.Forms.Button();
            this.cmdRound = new System.Windows.Forms.Button();
            this.lblChange = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_quarter = new System.Windows.Forms.Button();
            this.btn_third = new System.Windows.Forms.Button();
            this.btn_half = new System.Windows.Forms.Button();
            this.btn_dot = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_00 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.bnt_3 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_100 = new System.Windows.Forms.Button();
            this.btn_50 = new System.Windows.Forms.Button();
            this.btn_25 = new System.Windows.Forms.Button();
            this.btn_10 = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.cmdVal = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtVal
            // 
            this.txtVal.Location = new System.Drawing.Point(245, 57);
            this.txtVal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtVal.Name = "txtVal";
            this.txtVal.Size = new System.Drawing.Size(204, 22);
            this.txtVal.TabIndex = 1;
            this.txtVal.TextChanged += new System.EventHandler(this.txtVal_TextChanged);
            // 
            // txtpad
            // 
            this.txtpad.Location = new System.Drawing.Point(245, 97);
            this.txtpad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtpad.Name = "txtpad";
            this.txtpad.Size = new System.Drawing.Size(204, 22);
            this.txtpad.TabIndex = 2;
            this.txtpad.TextChanged += new System.EventHandler(this.txtpad_TextChanged);
            // 
            // cmdCash
            // 
            this.cmdCash.Location = new System.Drawing.Point(739, 228);
            this.cmdCash.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdCash.Name = "cmdCash";
            this.cmdCash.Size = new System.Drawing.Size(112, 87);
            this.cmdCash.TabIndex = 3;
            this.cmdCash.Text = "Cash";
            this.cmdCash.UseVisualStyleBackColor = true;
            this.cmdCash.Click += new System.EventHandler(this.btn_Cash_Click);
            // 
            // cmdCredit
            // 
            this.cmdCredit.Location = new System.Drawing.Point(739, 322);
            this.cmdCredit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdCredit.Name = "cmdCredit";
            this.cmdCredit.Size = new System.Drawing.Size(112, 87);
            this.cmdCredit.TabIndex = 4;
            this.cmdCredit.Text = "Credit Card";
            this.cmdCredit.UseVisualStyleBackColor = true;
            this.cmdCredit.Click += new System.EventHandler(this.cmdCredit_Click);
            // 
            // cmdRound
            // 
            this.cmdRound.Location = new System.Drawing.Point(739, 417);
            this.cmdRound.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdRound.Name = "cmdRound";
            this.cmdRound.Size = new System.Drawing.Size(112, 87);
            this.cmdRound.TabIndex = 5;
            this.cmdRound.Text = "Round off";
            this.cmdRound.UseVisualStyleBackColor = true;
            this.cmdRound.Click += new System.EventHandler(this.cmdRound_Click);
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Location = new System.Drawing.Point(241, 60);
            this.lblChange.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(0, 17);
            this.lblChange.TabIndex = 6;
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.Red;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Location = new System.Drawing.Point(555, 479);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(84, 76);
            this.btn_clear.TabIndex = 79;
            this.btn_clear.Text = "C";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click_1);
            // 
            // btn_quarter
            // 
            this.btn_quarter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_quarter.Location = new System.Drawing.Point(555, 395);
            this.btn_quarter.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_quarter.Name = "btn_quarter";
            this.btn_quarter.Size = new System.Drawing.Size(84, 76);
            this.btn_quarter.TabIndex = 78;
            this.btn_quarter.Text = "1/4";
            this.btn_quarter.UseVisualStyleBackColor = true;
            this.btn_quarter.Click += new System.EventHandler(this.btn_quarter_Click);
            // 
            // btn_third
            // 
            this.btn_third.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_third.Location = new System.Drawing.Point(555, 311);
            this.btn_third.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_third.Name = "btn_third";
            this.btn_third.Size = new System.Drawing.Size(84, 76);
            this.btn_third.TabIndex = 77;
            this.btn_third.Text = "1/3";
            this.btn_third.UseVisualStyleBackColor = true;
            this.btn_third.Click += new System.EventHandler(this.btn_third_Click);
            // 
            // btn_half
            // 
            this.btn_half.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_half.Location = new System.Drawing.Point(555, 228);
            this.btn_half.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_half.Name = "btn_half";
            this.btn_half.Size = new System.Drawing.Size(84, 76);
            this.btn_half.TabIndex = 76;
            this.btn_half.Text = "1/2";
            this.btn_half.UseVisualStyleBackColor = true;
            this.btn_half.Click += new System.EventHandler(this.btn_half_Click);
            // 
            // btn_dot
            // 
            this.btn_dot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dot.Location = new System.Drawing.Point(429, 479);
            this.btn_dot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_dot.Name = "btn_dot";
            this.btn_dot.Size = new System.Drawing.Size(84, 76);
            this.btn_dot.TabIndex = 75;
            this.btn_dot.Text = ".";
            this.btn_dot.UseVisualStyleBackColor = true;
            this.btn_dot.Click += new System.EventHandler(this.btn_dot_Click);
            // 
            // btn_0
            // 
            this.btn_0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_0.Location = new System.Drawing.Point(337, 479);
            this.btn_0.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(84, 76);
            this.btn_0.TabIndex = 74;
            this.btn_0.Text = "0";
            this.btn_0.UseVisualStyleBackColor = true;
            this.btn_0.Click += new System.EventHandler(this.btn_0_Click);
            // 
            // btn_00
            // 
            this.btn_00.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_00.Location = new System.Drawing.Point(245, 479);
            this.btn_00.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_00.Name = "btn_00";
            this.btn_00.Size = new System.Drawing.Size(84, 76);
            this.btn_00.TabIndex = 73;
            this.btn_00.Text = "00";
            this.btn_00.UseVisualStyleBackColor = true;
            this.btn_00.Click += new System.EventHandler(this.btn_00_Click);
            // 
            // btn_9
            // 
            this.btn_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_9.Location = new System.Drawing.Point(429, 395);
            this.btn_9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(84, 76);
            this.btn_9.TabIndex = 72;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = true;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_8
            // 
            this.btn_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_8.Location = new System.Drawing.Point(337, 395);
            this.btn_8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(84, 76);
            this.btn_8.TabIndex = 71;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = true;
            this.btn_8.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // btn_7
            // 
            this.btn_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_7.Location = new System.Drawing.Point(245, 395);
            this.btn_7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(84, 76);
            this.btn_7.TabIndex = 70;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = true;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // btn_6
            // 
            this.btn_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_6.Location = new System.Drawing.Point(429, 311);
            this.btn_6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(84, 76);
            this.btn_6.TabIndex = 69;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = true;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // btn_5
            // 
            this.btn_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_5.Location = new System.Drawing.Point(337, 311);
            this.btn_5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(84, 76);
            this.btn_5.TabIndex = 68;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = true;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_4
            // 
            this.btn_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_4.Location = new System.Drawing.Point(245, 311);
            this.btn_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(84, 76);
            this.btn_4.TabIndex = 67;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = true;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // bnt_3
            // 
            this.bnt_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bnt_3.Location = new System.Drawing.Point(429, 228);
            this.bnt_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bnt_3.Name = "bnt_3";
            this.bnt_3.Size = new System.Drawing.Size(84, 76);
            this.bnt_3.TabIndex = 66;
            this.bnt_3.Text = "3";
            this.bnt_3.UseVisualStyleBackColor = true;
            this.bnt_3.Click += new System.EventHandler(this.bnt_3_Click);
            // 
            // btn_2
            // 
            this.btn_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_2.Location = new System.Drawing.Point(337, 228);
            this.btn_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(84, 76);
            this.btn_2.TabIndex = 65;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = true;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_1
            // 
            this.btn_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_1.Location = new System.Drawing.Point(245, 228);
            this.btn_1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(84, 76);
            this.btn_1.TabIndex = 64;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btn_100
            // 
            this.btn_100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_100.Location = new System.Drawing.Point(119, 479);
            this.btn_100.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_100.Name = "btn_100";
            this.btn_100.Size = new System.Drawing.Size(84, 76);
            this.btn_100.TabIndex = 63;
            this.btn_100.Text = "100";
            this.btn_100.UseVisualStyleBackColor = true;
            this.btn_100.Click += new System.EventHandler(this.btn_100_Click);
            // 
            // btn_50
            // 
            this.btn_50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_50.Location = new System.Drawing.Point(119, 395);
            this.btn_50.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_50.Name = "btn_50";
            this.btn_50.Size = new System.Drawing.Size(84, 76);
            this.btn_50.TabIndex = 62;
            this.btn_50.Text = "50";
            this.btn_50.UseVisualStyleBackColor = true;
            this.btn_50.Click += new System.EventHandler(this.btn_50_Click);
            // 
            // btn_25
            // 
            this.btn_25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_25.Location = new System.Drawing.Point(119, 311);
            this.btn_25.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_25.Name = "btn_25";
            this.btn_25.Size = new System.Drawing.Size(84, 76);
            this.btn_25.TabIndex = 61;
            this.btn_25.Text = "25";
            this.btn_25.UseVisualStyleBackColor = true;
            this.btn_25.Click += new System.EventHandler(this.btn_25_Click);
            // 
            // btn_10
            // 
            this.btn_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_10.Location = new System.Drawing.Point(119, 228);
            this.btn_10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_10.Name = "btn_10";
            this.btn_10.Size = new System.Drawing.Size(84, 76);
            this.btn_10.TabIndex = 60;
            this.btn_10.Text = "10";
            this.btn_10.UseVisualStyleBackColor = true;
            this.btn_10.Click += new System.EventHandler(this.btn_10_Click);
            // 
            // btnAll
            // 
            this.btnAll.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Location = new System.Drawing.Point(647, 228);
            this.btnAll.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(84, 76);
            this.btnAll.TabIndex = 80;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = false;
            this.btnAll.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmdVal
            // 
            this.cmdVal.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cmdVal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdVal.Location = new System.Drawing.Point(647, 311);
            this.cmdVal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdVal.Name = "cmdVal";
            this.cmdVal.Size = new System.Drawing.Size(84, 76);
            this.cmdVal.TabIndex = 81;
            this.cmdVal.UseVisualStyleBackColor = false;
            this.cmdVal.Click += new System.EventHandler(this.cmdVal_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 674);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 82;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // frmBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(984, 709);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmdVal);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_quarter);
            this.Controls.Add(this.btn_third);
            this.Controls.Add(this.btn_half);
            this.Controls.Add(this.btn_dot);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_00);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.bnt_3);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.btn_100);
            this.Controls.Add(this.btn_50);
            this.Controls.Add(this.btn_25);
            this.Controls.Add(this.btn_10);
            this.Controls.Add(this.lblChange);
            this.Controls.Add(this.cmdRound);
            this.Controls.Add(this.cmdCredit);
            this.Controls.Add(this.cmdCash);
            this.Controls.Add(this.txtpad);
            this.Controls.Add(this.txtVal);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmBill";
            this.Text = "frmBill";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmBill_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtVal;
        private System.Windows.Forms.TextBox txtpad;
        private System.Windows.Forms.Button cmdCash;
        private System.Windows.Forms.Button cmdCredit;
        private System.Windows.Forms.Button cmdRound;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_quarter;
        private System.Windows.Forms.Button btn_third;
        private System.Windows.Forms.Button btn_half;
        private System.Windows.Forms.Button btn_dot;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_00;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button bnt_3;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_100;
        private System.Windows.Forms.Button btn_50;
        private System.Windows.Forms.Button btn_25;
        private System.Windows.Forms.Button btn_10;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button cmdVal;
        private System.Windows.Forms.Button button1;
    }
}