﻿/************************************************************************
	Filename 	 :	frmClient.cs
	Created  	 :	28/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Form for managing clients
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;

namespace restoPOS.Forms.Sale.Client
{
    public partial class frmClient : Form
    {
        private Entities.Client selectedClient;

        public frmClient()
        {
            InitializeComponent();
            cbTitle.SelectedText = "NONE";
            PopulateClients();

            if (lbClients.Items.Count > 0)
                lbClients.SelectedIndex = 0;
        }

        /// <summary>
        /// Populates the Client list</summary>
        private void PopulateClients()
        {
            try
            {
                lbClients.Items.Clear();
                lbClients.DisplayMember = "Client";
                lbClients.ValueMember = "ID";

                Hashtable clientInfo = Common.DoSqlQuery("SELECT * FROM Client", new short[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });
                foreach (DictionaryEntry row in clientInfo)
                {
                    Entities.Client newClient = new Entities.Client();
                    newClient.ID = Convert.ToString(((Hashtable)row.Value)[0]);
                    newClient.IdentityNumber = Convert.ToString(((Hashtable)row.Value)[1]);
                    newClient.FName = Convert.ToString(((Hashtable)row.Value)[2]);
                    newClient.LName = Convert.ToString(((Hashtable)row.Value)[3]);
                    newClient.Title = Convert.ToString(((Hashtable)row.Value)[4]);
                    newClient.DOB = Convert.ToDateTime(((Hashtable)row.Value)[5]);
                    newClient.Road = Convert.ToString(((Hashtable)row.Value)[6]);
                    newClient.Town = Convert.ToString(((Hashtable)row.Value)[7]);
                    newClient.District = Convert.ToString(((Hashtable)row.Value)[8]);
                    newClient.HomeNumber = Convert.ToString(((Hashtable)row.Value)[9]);
                    newClient.MobileNumber = Convert.ToString(((Hashtable)row.Value)[10]);

                    lbClients.Items.Add(newClient);
                }

                if (lbClients.Items.Count == 0)
                    lblNoClient.Visible = true;
                else
                    lblNoClient.Visible = false;
                btnDelete.Enabled = !lblNoClient.Visible;
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Updates the information fields</summary>
        private void UpdateInformaiton()
        {
            if (selectedClient == null || selectedClient.ID.Equals(""))
            {
                lblID.Text = "-";
                tbIDNo.Text = tbFName.Text = tbLName.Text = tbRoad.Text = tbTown.Text = tbDistrict.Text = tbHomeTel.Text = tbMobilTel.Text = "";
                cbTitle.SelectedText = "NONE";
                //dtpDOB.Value = selectedClient.DOB;
            }
            else
            {
                lblID.Text = selectedClient.ID;
                tbIDNo.Text = selectedClient.IdentityNumber;
                tbFName.Text = selectedClient.FName;
                tbLName.Text = selectedClient.LName;
                dtpDOB.Value = selectedClient.DOB;
                tbRoad.Text = selectedClient.Road;
                tbTown.Text = selectedClient.Town;
                tbDistrict.Text = selectedClient.District;
                tbHomeTel.Text = selectedClient.HomeNumber;
                tbMobilTel.Text = selectedClient.MobileNumber;

                if (selectedClient.Title.Equals(""))
                    cbTitle.Text = "NONE";
                else
                    cbTitle.Text = selectedClient.Title;
            }
        }

        private void lbClients_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedClient = ((Entities.Client)lbClients.SelectedItem);
            UpdateInformaiton();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (Common.DeleteRecord("Are you sure you want to delete the client '" + lbClients.Text + "'? This action cannot be undone ",
                                        "Delete client", "DELETE FROM Client WHERE Client_ID = " + selectedClient.ID))
                {
                    PopulateClients();
                    if (lbClients.Items.Count > 0)
                        lbClients.SelectedIndex = 0;
                    else
                        selectedClient = null;

                    UpdateInformaiton();
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnModifUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();

                if (btnModifUpdate.Tag.Equals("0"))
                {
                    btnModifUpdate.Tag = "1";
                    tbIDNo.ReadOnly = tbFName.ReadOnly = tbLName.ReadOnly = tbRoad.ReadOnly = tbTown.ReadOnly = tbDistrict.ReadOnly =
                        tbHomeTel.ReadOnly = tbMobilTel.ReadOnly = false;
                    cbTitle.Enabled = dtpDOB.Enabled = true;
                    btnModif_Cancel.Visible = true;
                    btnModifUpdate.Text = "Update";
                }
                else
                {
                    if (!Common.TextBoxIsValid(tbIDNo, generalErrorToolTip, true, 15))
                        return;

                    if (!Common.TextBoxIsValid(tbFName, generalErrorToolTip, true, 20))
                        return;
                    if (!Common.TextBoxIsValid(tbLName, generalErrorToolTip, true, 20))
                        return;

                    if (!Common.TextBoxIsValid(tbRoad, generalErrorToolTip, false, 50))
                        return;
                    if (!Common.TextBoxIsValid(tbTown, generalErrorToolTip, false, 20))
                        return;
                    if (!Common.TextBoxIsValid(tbDistrict, generalErrorToolTip, false, 20))
                        return;

                    if (!Common.TextBoxIsValid(tbHomeTel, generalErrorToolTip, false, 12))
                        return;
                    if (!Common.TextBoxIsValid(tbMobilTel, generalErrorToolTip, false, 12))
                        return;

                    double num;
                    if (!tbHomeTel.Text.Equals("") && !double.TryParse(tbHomeTel.Text, out num))
                    {
                        Common.ShowErrorToolTip(generalErrorToolTip, "Field can only accept numbers", tbHomeTel);
                        return;
                    }
                    if (!tbMobilTel.Text.Equals("") && !double.TryParse(tbMobilTel.Text, out num))
                    {
                        Common.ShowErrorToolTip(generalErrorToolTip, "Field can only accept numbers", tbMobilTel);
                        return;
                    }

                    string sqlCommand;
                    if (btnModifUpdate.Text.Equals("Update"))
                    {
                        if (Common.ValueExistInTable("Client", "Client_IDNumber = '" + tbIDNo.Text + "'")
                        && !tbIDNo.Text.Equals(selectedClient.IdentityNumber))
                        {
                            generalErrorToolTip.Active = false;
                            generalErrorToolTip.RemoveAll();

                            Common.ShowErrorToolTip(generalErrorToolTip, "The client identification card number already exist, please chose another", tbIDNo);
                            return;
                        }

                        if (cbTitle.SelectedText.Equals("NONE"))
                            sqlCommand = "UPDATE Client SET Client_IDNumber = '" + tbIDNo.Text + "', Client_FName = '" + tbFName.Text +
                                         "', Client_LName = '" + tbLName.Text +
                                         "', Client_DOB = '" + dtpDOB.Value.ToString("yyyy-MM-dd") + "', Client_Road = '" + tbRoad.Text +
                                         "', Client_Town = '" + tbTown.Text + "', Client_District = '" + tbDistrict.Text +
                                         "', Client_telHome = '" + tbHomeTel.Text + "', Client_telMobile = '" + tbMobilTel.Text +
                                         "' WHERE Client_ID = " + lblID.Text;
                        else
                            sqlCommand = "UPDATE Client SET Client_IDNumber = '" + tbIDNo.Text + "', Client_FName = '" + tbFName.Text +
                                         "', Client_LName = '" + tbLName.Text + "', Client_Title = '" + cbTitle.Text +
                                         "', Client_DOB = '" + dtpDOB.Value.ToString("yyyy-MM-dd") + "', Client_Road = '" + tbRoad.Text +
                                         "', Client_Town = '" + tbTown.Text + "', Client_District = '" + tbDistrict.Text +
                                         "', Client_telHome = '" + tbHomeTel.Text + "', Client_telMobile = '" + tbMobilTel.Text +
                                         "' WHERE Client_ID = " + lblID.Text;
                    }
                    else // Add
                    {
                        if (Common.ValueExistInTable("Client", "Client_IDNumber = '" + tbIDNo.Text + "'"))
                        {
                            generalErrorToolTip.Active = false;
                            generalErrorToolTip.RemoveAll();

                            Common.ShowErrorToolTip(generalErrorToolTip, "The client identification card number already exist, please chose another", tbIDNo);
                            return;
                        }

                        if (cbTitle.SelectedText.Equals("NONE"))
                            sqlCommand = "INSERT INTO Client (Client_IDNumber, Client_FName, Client_LName, Client_DOB, Client_Road, " +
                                         "Client_Town, Client_District, Client_telHome, Client_telMobile) VALUES " +
                                         "('" + tbIDNo.Text + "','" + tbFName.Text + "','" + tbLName.Text + "','" +
                                         dtpDOB.Value.ToString("yyyy-MM-dd") + "','" + tbRoad.Text + "','" + tbTown.Text + "','" + tbDistrict.Text + "','" +
                                         tbHomeTel.Text + "','" + tbMobilTel.Text + "');";
                        else
                            sqlCommand = "INSERT INTO Client (Client_IDNumber, Client_FName, Client_LName, Client_Title, Client_DOB, Client_Road, " +
                                         "Client_Town, Client_District, Client_telHome, Client_telMobile) VALUES " +
                                         "('" + tbIDNo.Text + "','" + tbFName.Text + "','" + tbLName.Text + "','" + cbTitle.Text + "','" +
                                         dtpDOB.Value.ToString("yyyy-MM-dd") + "','" + tbRoad.Text + "','" + tbTown.Text + "','" + tbDistrict.Text + "','" +
                                         tbHomeTel.Text + "','" + tbMobilTel.Text + "');";
                    }

                    if (Common.DoSqlNonQuery(sqlCommand) == 0)
                        MessageBox.Show("An error occurred, records not affected", "Unexpected error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        PopulateClients();
                        lbClients.SelectedIndex = 0;
                        btnModif_Cancel_Click(btnModif_Cancel, e);
                    }
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnModif_Cancel_Click(object sender, EventArgs e)
        {
            btnModifUpdate.Tag = "0";
            tbIDNo.ReadOnly = tbFName.ReadOnly = tbLName.ReadOnly = tbRoad.ReadOnly = tbTown.ReadOnly = tbDistrict.ReadOnly =
                tbHomeTel.ReadOnly = tbMobilTel.ReadOnly = true;
            cbTitle.Enabled = dtpDOB.Enabled = false;
            btnModif_Cancel.Visible = false;
            btnModifUpdate.Text = "Modify";

            UpdateInformaiton();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            btnModifUpdate.Tag = "1";
            tbIDNo.ReadOnly = tbFName.ReadOnly = tbLName.ReadOnly = tbRoad.ReadOnly = tbTown.ReadOnly = tbDistrict.ReadOnly =
                tbHomeTel.ReadOnly = tbMobilTel.ReadOnly = false;
            cbTitle.Enabled = dtpDOB.Enabled = true;
            btnModif_Cancel.Visible = true;
            btnModifUpdate.Text = "Add";

            lblID.Text = "-";
            tbIDNo.Text = tbFName.Text = tbLName.Text = tbRoad.Text = tbTown.Text = tbDistrict.Text = tbHomeTel.Text = tbMobilTel.Text = "";
            cbTitle.SelectedText = "NONE";

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();
        }

        private void tbName_TextChanged(object sender, EventArgs e)
        {
            Common.TextBoxIsValid((TextBox)sender, generalErrorToolTip, true, 20);
        }

        private void tbRoad_TextChanged(object sender, EventArgs e)
        {
            Common.TextBoxIsValid((TextBox)sender, generalErrorToolTip, false, 50);
        }

        private void tbTownAndDistrict_TextChanged(object sender, EventArgs e)
        {
            Common.TextBoxIsValid((TextBox)sender, generalErrorToolTip, false, 20);
        }

        private void tbTels_TextChanged(object sender, EventArgs e)
        {
            Common.TextBoxIsValid((TextBox)sender, generalErrorToolTip, false, 12);
            double num;
            if ((!((TextBox)sender).Text.Equals("") && !double.TryParse(((TextBox)sender).Text, out num)))
                Common.ShowErrorToolTip(generalErrorToolTip, "Field can only accept numbers", ((TextBox)sender));
        }

        private void tbIDNo_TextChanged(object sender, EventArgs e)
        {
            Common.TextBoxIsValid((TextBox)sender, generalErrorToolTip, true, 15);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void llAdvSearch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //TODO: Implement adv. search
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            //TODO: Implement simple search
        }
    }
}
