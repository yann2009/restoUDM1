﻿/************************************************************************
	Filename 	 :	frmTable.cs
	Created  	 :	29/10/2013
	Author   	 :	Hisham MAUDARBOCUS
    Designer     :  Kawshik TONOO
	Description  :	Main form for table management
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;
using restoPOS.Commons;

namespace restoPOS.Forms.Sale.Table
{
    public partial class frmTable : Form
    {
        private bool pnlTable_isHidden = false;
        private bool flpRooms_isHidden = false;
        private bool subPanel_isHidden = false;
        private bool lblNoTbl_isHidden = false;

        private string selectedRoomID = "NONE";
        private string selectedRoomLabel = "";
        private string selectedTableID = "NONE";
        private string selectedTableLabel = "";

        public frmTableNewRoom newRoomForm = new frmTableNewRoom();
        public frmTable_NewTable_ModifInfo newTableForm = new frmTable_NewTable_ModifInfo();

        public frmTable()
        {
            InitializeComponent();

            /*newRoomForm.DataUpdated += new Table.frmTableNewRoom.AnnounceParentHandler((string newRoom) => {
                UpdateRooms();
                tcRoom.SelectedTab = tcRoom.TabPages[newRoom];
            });

            newTableForm.DataUpdated += new Table.frmTable_NewTable_ModifInfo.AnnounceParentHandler(() => {
                PopulateTables(tcRoom.SelectedTab);
            });*/

            UpdateRooms();
            flpRoom.Controls[0].Select();
            selectedRoomID = ((Button)(flpRoom.Controls[0])).Tag.ToString();
            PopulateTables(selectedRoomID);
        }

        /// <summary>
        /// Updates the Room list</summary>
        private void UpdateRooms()
        {
            try
            {
                flpRoom.Controls.Clear();

                Hashtable roomInfo = Common.DoSqlQuery("SELECT Room_ID, Room_Label FROM Room " + "ORDER BY Room_Label DESC", new short[] { 0, 1 });
                int controlIndex = 0;
                foreach (DictionaryEntry row in roomInfo)
                {
                    Button controlButton = new Button();
                    controlButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                    controlButton.Name = "flpRooms" + controlIndex++;
                    controlButton.Width = 172;
                    controlButton.Height = 36;
                    controlButton.Tag = Convert.ToString(((Hashtable)row.Value)[0]);   // Room_ID
                    controlButton.Text = Convert.ToString(((Hashtable)row.Value)[1]);   // Room_Label
                    controlButton.Click += new EventHandler(flpRoomControl_Click);

                    flpRoom.Controls.Add(controlButton);
                }

                if (flpRoom.Controls.Count == 0)
                    lblNoRooms.Visible = true;
                else
                    lblNoRooms.Visible = false;
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Populates the table list</summary>
        /// <param name="RoomID">
        /// The room ID in which the table belongs</param>
        private void PopulateTables(string RoomID)
        {
            try
            {
                flpTable.Controls.Clear();

                Hashtable roomInfo = Common.DoSqlQuery("SELECT RoomTable_ID, RoomTable_Status FROM RoomTable where Room_ID = " +
                                                       RoomID + " ORDER BY RoomTable_ID DESC", new short[] { 0, 1 });
                int controlIndex = 0;
                foreach (DictionaryEntry row in roomInfo)
                {
                    ucTables ucontrolTable = new ucTables();
                    ucontrolTable.Name = "ucFlpTable" + controlIndex++;
                    ucontrolTable.TableID = Convert.ToString(((Hashtable)row.Value)[0]);   // Table_ID
                    ucontrolTable.TableLabel = Convert.ToString(((Hashtable)row.Value)[0]);   // Table_ID
                    ucontrolTable.StatusTable = ((Entities.TableStatus)((Hashtable)row.Value)[1]);

                    ucontrolTable.TableClick += new EventHandler(flp_btnTable_Click);

                    flpTable.Controls.Add(ucontrolTable);
                }

                if (flpTable.Controls.Count == 0)
                    lblNoTables.Visible = true;
                else
                    lblNoTables.Visible = false;
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void flpRoomControl_Click(object sender, EventArgs e)
        {
            selectedRoomID = ((Button)sender).Tag.ToString();
            selectedRoomLabel = ((Button)sender).Text;
            PopulateTables(selectedRoomID);
        }

        private void flp_btnTable_Click(object sender, EventArgs e)
        {
            selectedTableID = ((ucTables)((Control)sender).Parent).TableID;
            selectedTableLabel = ((ucTables)((Control)sender).Parent).TableLabel;

            Forms.Sale.frmCheckout frm = new Forms.Sale.frmCheckout();
            frm.Show();
        }

        private void btnHideShow_Click(object sender, EventArgs e)
        {
            if (btnHideShow.Text.Equals("«"))
                btnHideShow.Text = "»";
            else
                btnHideShow.Text = "«";

            bool tempFlp = flpRooms_isHidden;
            bool tempSub = subPanel_isHidden;

            Animation.AnimationToggle(pnlTable, "Left", pnlTable.Width - 15, ref pnlTable_isHidden, 10);

            Animation.AnimationToggle(flpTable, "Left", pnlTable.Width - 15, ref flpRooms_isHidden, 10);
            Animation.AnimationToggle(flpTable, "Width", pnlTable.Width - 15, ref tempFlp, -10);

            Animation.AnimationToggle(pnlSub_Pannel, "Left", pnlTable.Width - 15, ref subPanel_isHidden, 10);
            Animation.AnimationToggle(pnlSub_Pannel, "Width", pnlTable.Width - 15, ref tempSub, -10);

            Animation.AnimationToggle(lblNoTables, "Left", (pnlTable.Width - 15) / 2, ref lblNoTbl_isHidden, 10);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Table_Add_Click(object sender, EventArgs e)
        {
            newTableForm.Show();
            newTableForm.Size = this.Size;
            newTableForm.Location = this.Location;
            newTableForm.TopMost = true;
            newTableForm.InitialiseFields(selectedRoomID, "New Table");
            Animation.FadeIn(newTableForm, 90, 5);
        }

        private void Table_Info_Click(object sender, EventArgs e)
        {
            newTableForm.Show();
            newTableForm.Size = this.Size;
            newTableForm.Location = this.Location;
            newTableForm.TopMost = true;
            newTableForm.InitialiseFields(selectedRoomID, "Modify/Information Table", selectedTableID);
            Animation.FadeIn(newTableForm, 90, 5);
        }

        private void Table_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (Common.DeleteRecord("Are you sure you want to delete the table '" + selectedTableLabel + "'? This action cannot be undone ",
                                        "Delete table", "DELETE FROM RoomTable WHERE RoomTable_ID = '" + selectedTableID + "' " +
                                        "AND Room_ID = " + selectedRoomID))
                {
                    selectedRoomID = ((Button)(flpRoom.Controls[0])).Tag.ToString();
                    PopulateTables(selectedRoomID);
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnAdd_flpRoom_Click(object sender, EventArgs e)
        {
            newRoomForm.Show();
            newRoomForm.Size = this.Size;
            newRoomForm.Location = this.Location;
            newRoomForm.TopMost = true;
            Animation.FadeIn(newRoomForm, 90, 5);
        }

        private void btnRemove_flpRoom_Click(object sender, EventArgs e)
        {
            try
            {
                if (Common.DeleteRecord("Are you sure you want to delete the room '" + selectedRoomLabel + "'? This action cannot be undone ",
                                        "Delete room", "DELETE FROM Room WHERE Room_ID = " + selectedRoomID))
                {
                    UpdateRooms();
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                MessageBox.Show(ex.Message, "Error");
            }
        }
    }
}
