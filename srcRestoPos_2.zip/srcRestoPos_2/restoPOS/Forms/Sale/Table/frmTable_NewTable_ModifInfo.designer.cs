﻿namespace restoPOS.Forms.Sale.Table
{
    partial class frmTable_NewTable_ModifInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.generalErrorToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.gbFields = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.lblNew_Label = new System.Windows.Forms.Label();
            this.btnNew_Cancel = new System.Windows.Forms.Button();
            this.tbTableID = new System.Windows.Forms.TextBox();
            this.btnNew_OK = new System.Windows.Forms.Button();
            this.gbFields.SuspendLayout();
            this.SuspendLayout();
            // 
            // generalErrorToolTip
            // 
            this.generalErrorToolTip.IsBalloon = true;
            this.generalErrorToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.generalErrorToolTip.ToolTipTitle = "Error";
            // 
            // gbFields
            // 
            this.gbFields.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbFields.Controls.Add(this.label1);
            this.gbFields.Controls.Add(this.cbStatus);
            this.gbFields.Controls.Add(this.lblNew_Label);
            this.gbFields.Controls.Add(this.btnNew_Cancel);
            this.gbFields.Controls.Add(this.tbTableID);
            this.gbFields.Controls.Add(this.btnNew_OK);
            this.gbFields.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbFields.ForeColor = System.Drawing.Color.White;
            this.gbFields.Location = new System.Drawing.Point(52, 69);
            this.gbFields.Name = "gbFields";
            this.gbFields.Size = new System.Drawing.Size(376, 117);
            this.gbFields.TabIndex = 11;
            this.gbFields.TabStop = false;
            this.gbFields.Text = "New Table";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Table Status :";
            // 
            // cbStatus
            // 
            this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Items.AddRange(new object[] {
            "Vacant",
            "Occupied",
            "Pending"});
            this.cbStatus.Location = new System.Drawing.Point(85, 55);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(280, 25);
            this.cbStatus.TabIndex = 9;
            // 
            // lblNew_Label
            // 
            this.lblNew_Label.AutoSize = true;
            this.lblNew_Label.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Label.ForeColor = System.Drawing.Color.White;
            this.lblNew_Label.Location = new System.Drawing.Point(6, 30);
            this.lblNew_Label.Name = "lblNew_Label";
            this.lblNew_Label.Size = new System.Drawing.Size(73, 13);
            this.lblNew_Label.TabIndex = 0;
            this.lblNew_Label.Text = "Table Name :";
            // 
            // btnNew_Cancel
            // 
            this.btnNew_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_Cancel.ForeColor = System.Drawing.Color.Black;
            this.btnNew_Cancel.Location = new System.Drawing.Point(90, 88);
            this.btnNew_Cancel.Name = "btnNew_Cancel";
            this.btnNew_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btnNew_Cancel.TabIndex = 8;
            this.btnNew_Cancel.Text = "Cancel";
            this.btnNew_Cancel.UseVisualStyleBackColor = true;
            this.btnNew_Cancel.Click += new System.EventHandler(this.btnNew_Cancel_Click);
            // 
            // tbTableID
            // 
            this.tbTableID.Location = new System.Drawing.Point(85, 24);
            this.tbTableID.Name = "tbTableID";
            this.tbTableID.Size = new System.Drawing.Size(280, 25);
            this.tbTableID.TabIndex = 1;
            this.tbTableID.Tag = "";
            this.tbTableID.TextChanged += new System.EventHandler(this.tbNewRoom_TextChanged);
            // 
            // btnNew_OK
            // 
            this.btnNew_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_OK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_OK.ForeColor = System.Drawing.Color.Black;
            this.btnNew_OK.Location = new System.Drawing.Point(9, 88);
            this.btnNew_OK.Name = "btnNew_OK";
            this.btnNew_OK.Size = new System.Drawing.Size(75, 23);
            this.btnNew_OK.TabIndex = 7;
            this.btnNew_OK.Text = "OK";
            this.btnNew_OK.UseVisualStyleBackColor = true;
            this.btnNew_OK.Click += new System.EventHandler(this.btnNew_OK_Click);
            // 
            // frmTable_NewTable_ModifInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(480, 254);
            this.Controls.Add(this.gbFields);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTable_NewTable_ModifInfo";
            this.Opacity = 0D;
            this.ShowInTaskbar = false;
            this.Text = "frmTable_NewTable_ModifInfo";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.gbFields.ResumeLayout(false);
            this.gbFields.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip generalErrorToolTip;
        private System.Windows.Forms.GroupBox gbFields;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbStatus;
        private System.Windows.Forms.Label lblNew_Label;
        private System.Windows.Forms.Button btnNew_Cancel;
        private System.Windows.Forms.TextBox tbTableID;
        private System.Windows.Forms.Button btnNew_OK;
    }
}