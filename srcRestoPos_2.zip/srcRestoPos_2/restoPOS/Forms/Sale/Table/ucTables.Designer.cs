﻿namespace restoPOS.Forms.Sale.Table
{
    partial class ucTables
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTable = new System.Windows.Forms.Label();
            this.btnTable = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTable
            // 
            this.lblTable.BackColor = System.Drawing.Color.White;
            this.lblTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTable.Location = new System.Drawing.Point(0, 93);
            this.lblTable.Name = "lblTable";
            this.lblTable.Size = new System.Drawing.Size(104, 35);
            this.lblTable.TabIndex = 1;
            this.lblTable.Text = "M21";
            this.lblTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnTable
            // 
            this.btnTable.BackColor = System.Drawing.Color.White;
            this.btnTable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTable.Location = new System.Drawing.Point(0, 0);
            this.btnTable.Name = "btnTable";
            this.btnTable.Size = new System.Drawing.Size(104, 94);
            this.btnTable.TabIndex = 0;
            this.btnTable.UseVisualStyleBackColor = false;
            this.btnTable.Click += new System.EventHandler(this.Table_Click);
            // 
            // ucTables
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblTable);
            this.Controls.Add(this.btnTable);
            this.Name = "ucTables";
            this.Size = new System.Drawing.Size(104, 128);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTable;
        private System.Windows.Forms.Button btnTable;
    }
}
