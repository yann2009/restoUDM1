﻿namespace restoPOS.Forms.Sale.Table
{
    partial class frmTableNewRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.generalErrorToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.gbNew = new System.Windows.Forms.GroupBox();
            this.lblNew_Label = new System.Windows.Forms.Label();
            this.btnNew_Cancel = new System.Windows.Forms.Button();
            this.tbNewRoom = new System.Windows.Forms.TextBox();
            this.btnNew_OK = new System.Windows.Forms.Button();
            this.gbNew.SuspendLayout();
            this.SuspendLayout();
            // 
            // generalErrorToolTip
            // 
            this.generalErrorToolTip.IsBalloon = true;
            this.generalErrorToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.generalErrorToolTip.ToolTipTitle = "Error";
            // 
            // gbNew
            // 
            this.gbNew.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbNew.Controls.Add(this.lblNew_Label);
            this.gbNew.Controls.Add(this.btnNew_Cancel);
            this.gbNew.Controls.Add(this.tbNewRoom);
            this.gbNew.Controls.Add(this.btnNew_OK);
            this.gbNew.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbNew.ForeColor = System.Drawing.Color.White;
            this.gbNew.Location = new System.Drawing.Point(115, 124);
            this.gbNew.Name = "gbNew";
            this.gbNew.Size = new System.Drawing.Size(376, 92);
            this.gbNew.TabIndex = 10;
            this.gbNew.TabStop = false;
            this.gbNew.Text = "New Room";
            // 
            // lblNew_Label
            // 
            this.lblNew_Label.AutoSize = true;
            this.lblNew_Label.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew_Label.ForeColor = System.Drawing.Color.White;
            this.lblNew_Label.Location = new System.Drawing.Point(6, 30);
            this.lblNew_Label.Name = "lblNew_Label";
            this.lblNew_Label.Size = new System.Drawing.Size(102, 13);
            this.lblNew_Label.TabIndex = 0;
            this.lblNew_Label.Text = "New Room Name :";
            // 
            // btnNew_Cancel
            // 
            this.btnNew_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_Cancel.ForeColor = System.Drawing.Color.Black;
            this.btnNew_Cancel.Location = new System.Drawing.Point(90, 63);
            this.btnNew_Cancel.Name = "btnNew_Cancel";
            this.btnNew_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btnNew_Cancel.TabIndex = 8;
            this.btnNew_Cancel.Text = "Cancel";
            this.btnNew_Cancel.UseVisualStyleBackColor = true;
            this.btnNew_Cancel.Click += new System.EventHandler(this.btnNew_Cancel_Click);
            // 
            // tbNewRoom
            // 
            this.tbNewRoom.Location = new System.Drawing.Point(114, 24);
            this.tbNewRoom.Name = "tbNewRoom";
            this.tbNewRoom.Size = new System.Drawing.Size(251, 25);
            this.tbNewRoom.TabIndex = 1;
            this.tbNewRoom.Tag = "";
            this.tbNewRoom.TextChanged += new System.EventHandler(this.tbNewRoom_TextChanged);
            // 
            // btnNew_OK
            // 
            this.btnNew_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNew_OK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew_OK.ForeColor = System.Drawing.Color.Black;
            this.btnNew_OK.Location = new System.Drawing.Point(9, 63);
            this.btnNew_OK.Name = "btnNew_OK";
            this.btnNew_OK.Size = new System.Drawing.Size(75, 23);
            this.btnNew_OK.TabIndex = 7;
            this.btnNew_OK.Text = "OK";
            this.btnNew_OK.UseVisualStyleBackColor = true;
            this.btnNew_OK.Click += new System.EventHandler(this.btnNew_OK_Click);
            // 
            // frmTableNewRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(608, 348);
            this.Controls.Add(this.gbNew);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTableNewRoom";
            this.Opacity = 0D;
            this.ShowInTaskbar = false;
            this.Text = "frmTableNew";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.gbNew.ResumeLayout(false);
            this.gbNew.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip generalErrorToolTip;
        private System.Windows.Forms.GroupBox gbNew;
        private System.Windows.Forms.Label lblNew_Label;
        private System.Windows.Forms.Button btnNew_Cancel;
        private System.Windows.Forms.TextBox tbNewRoom;
        private System.Windows.Forms.Button btnNew_OK;
    }
}