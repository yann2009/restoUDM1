﻿/************************************************************************
	Filename 	 :	frmTable_NewTable_ModifInfo.cs
	Created  	 :	29/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Form to add, view and modify tables
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using restoPOS.Commons;
using System.Data.SqlClient;
using System.Collections;

namespace restoPOS.Forms.Sale.Table
{
    public partial class frmTable_NewTable_ModifInfo : Form
    {
        public delegate void AnnounceParentHandler();
        public event AnnounceParentHandler DataUpdated;

        private string hostRoomID;
        private bool isModifyingMode;

        public frmTable_NewTable_ModifInfo()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initialize panel text and room ID where the table is contained</summary>
        /// <param name="roomID">
        /// The room ID in which the table is</param>
        /// <param name="panelText">
        /// Text to display on the panel</param>
        /// <param name="tableID">
        /// Table ID (specified in modifying/information mode)</param>
        public void InitialiseFields(string roomID, string panelText, string tableID = "")
        {
            try
            {
                gbFields.Text = panelText;
                cbStatus.SelectedIndex = -1;
                hostRoomID = roomID;

                if (panelText.Equals("New Table"))
                {
                    tbTableID.Enabled = true;
                    isModifyingMode = false;
                }
                else
                {
                    isModifyingMode = true;
                    tbTableID.Enabled = false;
                    tbTableID.Text = tableID;

                    Hashtable resultTable = Common.DoSqlQuery("SELECT RoomTable_Status FROM RoomTable WHERE RoomTable_ID = '" +
                                                              tbTableID.Text + "' AND Room_ID = " + roomID, new short[] { 0 });
                    Entities.TableStatus tableStatus = (Entities.TableStatus)(((Hashtable)resultTable[0])[0]);
                    cbStatus.Text = tableStatus.ToString();
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();
                MessageBox.Show(ex.Message, "Error");
            }
        }

        /// <summary>
        /// Hides the form and reset all fields to its original state</summary>
        /// <param name="fullHide">
        /// If true erase all fields</param>
        private void HideMe()
        {
            tbTableID.Text = "";
            cbStatus.SelectedIndex = -1;

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            Animation.FadeOut(this, 5);
            this.Hide();
        }

        private void btnNew_Cancel_Click(object sender, EventArgs e)
        {
            HideMe();
        }

        private void tbNewRoom_TextChanged(object sender, EventArgs e)
        {
            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            if (tbTableID.Text.Equals(""))
                Common.ShowErrorToolTip(generalErrorToolTip, "Empty Field", tbTableID);
            if (tbTableID.Text.Length > 10)
                Common.ShowErrorToolTip(generalErrorToolTip, "Text must be shorter than 10 characters", tbTableID);
        }

        private void btnNew_OK_Click(object sender, EventArgs e)
        {
            try
            {
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();

                if (tbTableID.Text.Equals(""))
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "Empty Field", tbTableID);
                    return;
                }
                if (tbTableID.Text.Length > 10)
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "Text must be shorter than 10 characters", tbTableID);
                    return;
                }
                if (cbStatus.Text.Equals(""))
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "Please select a status", cbStatus);
                    return;
                }

                if (Common.ValueExistInTable("RoomTable", "RoomTable_ID = '" + tbTableID.Text + "'") && !isModifyingMode)
                {
                    generalErrorToolTip.Active = false;
                    generalErrorToolTip.RemoveAll();

                    Common.ShowErrorToolTip(generalErrorToolTip, "The table already exist, please chose another", tbTableID);
                }
                else
                {
                    Entities.TableStatus tblStatus = (Entities.TableStatus)Enum.Parse(typeof(Entities.TableStatus), cbStatus.Text, true);
                    if(isModifyingMode)
                    {
                        if (Common.DoSqlNonQuery("UPDATE RoomTable SET RoomTable_Status = " + (int)tblStatus +
                                                 " WHERE RoomTable_ID = '" + tbTableID.Text + "' AND Room_ID = " + hostRoomID) == 0)
                            MessageBox.Show("An error occurred, records not affected", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        else
                        {
                            DataUpdated();
                            HideMe();
                        }
                    }
                    else
                    {
                        if (Common.DoSqlNonQuery("INSERT INTO RoomTable (RoomTable_ID, Room_ID, RoomTable_Status) VALUES ('"
                                                 + tbTableID.Text + "', " + hostRoomID + ", " + (int)tblStatus +")") == 0)
                        MessageBox.Show("An error occurred, records not affected", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        else
                        {
                            DataUpdated();
                            HideMe();
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();
                MessageBox.Show(ex.Message, "Error");
            }
        }
    }
}
