﻿/************************************************************************
	Filename 	 :	frmTableNewRoom.cs
	Created  	 :	03/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Form to add rooms
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using restoPOS.Commons;
using System.Data.SqlClient;

namespace restoPOS.Forms.Sale.Table
{
    public partial class frmTableNewRoom : Form
    {
        public delegate void AnnounceParentHandler(string newRoom);
        //public event AnnounceParentHandler FormHidden;
        public event AnnounceParentHandler DataUpdated;

        public frmTableNewRoom()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Hides the form and reset all fields to its original state</summary>
        /// <param name="fullHide">
        /// If true erase all fields</param>
        private void HideMe()
        {
            tbNewRoom.Text = "";

            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            //FormHidden();
            Animation.FadeOut(this, 5);
            this.Hide();
        }

        private void btnNew_Cancel_Click(object sender, EventArgs e)
        {
            HideMe();
        }

        private void tbNewRoom_TextChanged(object sender, EventArgs e)
        {
            generalErrorToolTip.Active = false;
            generalErrorToolTip.RemoveAll();

            if (tbNewRoom.Text.Equals(""))
                Common.ShowErrorToolTip(generalErrorToolTip, "Empty Field", tbNewRoom);
            if (tbNewRoom.Text.Length > 30)
                Common.ShowErrorToolTip(generalErrorToolTip, "Text must be shorter than 30 characters", tbNewRoom);
        }

        private void btnNew_OK_Click(object sender, EventArgs e)
        {
            try
            {
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();

                if (tbNewRoom.Text.Equals(""))
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "Empty Field", tbNewRoom);
                    return;
                }
                if (tbNewRoom.Text.Length > 30)
                {
                    Common.ShowErrorToolTip(generalErrorToolTip, "Text must be shorter than 30 characters", tbNewRoom);
                    return;
                }

                if (Common.ValueExistInTable("Room", "Room_ILabel = '" + tbNewRoom.Text + "'"))
                {
                    generalErrorToolTip.Active = false;
                    generalErrorToolTip.RemoveAll();

                    Common.ShowErrorToolTip(generalErrorToolTip, "The room label already exist, please chose another", tbNewRoom);
                }
                else
                {
                    if (Common.DoSqlNonQuery("INSERT INTO Room (Room_ILabel) VALUES ('" + tbNewRoom.Text + "')") == 0)
                        MessageBox.Show("An error occurred, records not affected", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        DataUpdated(tbNewRoom.Text);
                        HideMe();
                    }
                }
            }
            catch (SqlException ex)
            {
                //TODO: Implement catch exception handler
                generalErrorToolTip.Active = false;
                generalErrorToolTip.RemoveAll();
                MessageBox.Show(ex.Message, "Error");
            }
        }
    }
}
