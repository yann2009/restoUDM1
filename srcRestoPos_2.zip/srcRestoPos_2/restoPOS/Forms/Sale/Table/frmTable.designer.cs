﻿namespace restoPOS.Forms.Sale.Table
{
    partial class frmTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTable));
            this.pnlTable = new System.Windows.Forms.Panel();
            this.flpRoom = new System.Windows.Forms.FlowLayoutPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.btnHideShow = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblTable = new System.Windows.Forms.Label();
            this.flpTable = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlSub_Pannel = new System.Windows.Forms.Panel();
            this.lblSub_Info = new System.Windows.Forms.Label();
            this.pcSub_Info = new System.Windows.Forms.PictureBox();
            this.lblSub_Name = new System.Windows.Forms.Label();
            this.lblSub_Add = new System.Windows.Forms.Label();
            this.pcSub_Add = new System.Windows.Forms.PictureBox();
            this.lblSub_Delete = new System.Windows.Forms.Label();
            this.pcSub_Delete = new System.Windows.Forms.PictureBox();
            this.lblNoTables = new System.Windows.Forms.Label();
            this.lblNoRooms = new System.Windows.Forms.Label();
            this.btnAdd_flpRoom = new System.Windows.Forms.Button();
            this.btnRemove_flpRoom = new System.Windows.Forms.Button();
            this.pnlTable.SuspendLayout();
            this.flpRoom.SuspendLayout();
            this.pnlSub_Pannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Info)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Delete)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTable
            // 
            this.pnlTable.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlTable.BackColor = System.Drawing.Color.Silver;
            this.pnlTable.Controls.Add(this.btnRemove_flpRoom);
            this.pnlTable.Controls.Add(this.btnAdd_flpRoom);
            this.pnlTable.Controls.Add(this.flpRoom);
            this.pnlTable.Controls.Add(this.btnHideShow);
            this.pnlTable.Controls.Add(this.btnBack);
            this.pnlTable.Controls.Add(this.lblTable);
            this.pnlTable.Location = new System.Drawing.Point(0, 0);
            this.pnlTable.Name = "pnlTable";
            this.pnlTable.Size = new System.Drawing.Size(222, 549);
            this.pnlTable.TabIndex = 0;
            // 
            // flpRoom
            // 
            this.flpRoom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.flpRoom.Controls.Add(this.button2);
            this.flpRoom.Location = new System.Drawing.Point(3, 71);
            this.flpRoom.Name = "flpRoom";
            this.flpRoom.Size = new System.Drawing.Size(198, 414);
            this.flpRoom.TabIndex = 17;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(172, 36);
            this.button2.TabIndex = 2;
            this.button2.Text = "Salon";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btnHideShow
            // 
            this.btnHideShow.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnHideShow.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnHideShow.BackColor = System.Drawing.Color.White;
            this.btnHideShow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHideShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHideShow.Location = new System.Drawing.Point(207, 159);
            this.btnHideShow.Name = "btnHideShow";
            this.btnHideShow.Size = new System.Drawing.Size(16, 233);
            this.btnHideShow.TabIndex = 16;
            this.btnHideShow.Text = "«";
            this.btnHideShow.UseVisualStyleBackColor = false;
            this.btnHideShow.Click += new System.EventHandler(this.btnHideShow_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBack.Location = new System.Drawing.Point(3, 520);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "<< Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblTable
            // 
            this.lblTable.AutoSize = true;
            this.lblTable.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTable.Location = new System.Drawing.Point(8, 8);
            this.lblTable.Name = "lblTable";
            this.lblTable.Size = new System.Drawing.Size(111, 45);
            this.lblTable.TabIndex = 0;
            this.lblTable.Text = "Tables";
            // 
            // flpTable
            // 
            this.flpTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpTable.Location = new System.Drawing.Point(228, 1);
            this.flpTable.Name = "flpTable";
            this.flpTable.Size = new System.Drawing.Size(521, 501);
            this.flpTable.TabIndex = 17;
            // 
            // pnlSub_Pannel
            // 
            this.pnlSub_Pannel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlSub_Pannel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Info);
            this.pnlSub_Pannel.Controls.Add(this.pcSub_Info);
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Name);
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Add);
            this.pnlSub_Pannel.Controls.Add(this.pcSub_Add);
            this.pnlSub_Pannel.Controls.Add(this.lblSub_Delete);
            this.pnlSub_Pannel.Controls.Add(this.pcSub_Delete);
            this.pnlSub_Pannel.Location = new System.Drawing.Point(221, 508);
            this.pnlSub_Pannel.Name = "pnlSub_Pannel";
            this.pnlSub_Pannel.Size = new System.Drawing.Size(531, 41);
            this.pnlSub_Pannel.TabIndex = 31;
            this.pnlSub_Pannel.Tag = "NONE";
            // 
            // lblSub_Info
            // 
            this.lblSub_Info.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Info.AutoSize = true;
            this.lblSub_Info.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSub_Info.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Info.ForeColor = System.Drawing.Color.White;
            this.lblSub_Info.Location = new System.Drawing.Point(316, 14);
            this.lblSub_Info.Name = "lblSub_Info";
            this.lblSub_Info.Size = new System.Drawing.Size(109, 13);
            this.lblSub_Info.TabIndex = 6;
            this.lblSub_Info.Text = "Modify/Information";
            this.lblSub_Info.Click += new System.EventHandler(this.Table_Info_Click);
            // 
            // pcSub_Info
            // 
            this.pcSub_Info.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pcSub_Info.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcSub_Info.Image = ((System.Drawing.Image)(resources.GetObject("pcSub_Info.Image")));
            this.pcSub_Info.Location = new System.Drawing.Point(290, 9);
            this.pcSub_Info.Name = "pcSub_Info";
            this.pcSub_Info.Size = new System.Drawing.Size(20, 26);
            this.pcSub_Info.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcSub_Info.TabIndex = 5;
            this.pcSub_Info.TabStop = false;
            this.pcSub_Info.Click += new System.EventHandler(this.Table_Info_Click);
            // 
            // lblSub_Name
            // 
            this.lblSub_Name.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Name.ForeColor = System.Drawing.Color.White;
            this.lblSub_Name.Location = new System.Drawing.Point(12, 11);
            this.lblSub_Name.Name = "lblSub_Name";
            this.lblSub_Name.Size = new System.Drawing.Size(170, 21);
            this.lblSub_Name.TabIndex = 4;
            this.lblSub_Name.Text = "Table 001";
            // 
            // lblSub_Add
            // 
            this.lblSub_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Add.AutoSize = true;
            this.lblSub_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSub_Add.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Add.ForeColor = System.Drawing.Color.White;
            this.lblSub_Add.Location = new System.Drawing.Point(457, 14);
            this.lblSub_Add.Name = "lblSub_Add";
            this.lblSub_Add.Size = new System.Drawing.Size(58, 13);
            this.lblSub_Add.TabIndex = 3;
            this.lblSub_Add.Text = "Add Table";
            this.lblSub_Add.Click += new System.EventHandler(this.Table_Add_Click);
            // 
            // pcSub_Add
            // 
            this.pcSub_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pcSub_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcSub_Add.Image = ((System.Drawing.Image)(resources.GetObject("pcSub_Add.Image")));
            this.pcSub_Add.Location = new System.Drawing.Point(431, 9);
            this.pcSub_Add.Name = "pcSub_Add";
            this.pcSub_Add.Size = new System.Drawing.Size(20, 26);
            this.pcSub_Add.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcSub_Add.TabIndex = 2;
            this.pcSub_Add.TabStop = false;
            this.pcSub_Add.Click += new System.EventHandler(this.Table_Add_Click);
            // 
            // lblSub_Delete
            // 
            this.lblSub_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSub_Delete.AutoSize = true;
            this.lblSub_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSub_Delete.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub_Delete.ForeColor = System.Drawing.Color.White;
            this.lblSub_Delete.Location = new System.Drawing.Point(214, 14);
            this.lblSub_Delete.Name = "lblSub_Delete";
            this.lblSub_Delete.Size = new System.Drawing.Size(70, 13);
            this.lblSub_Delete.TabIndex = 1;
            this.lblSub_Delete.Text = "Delete Table";
            this.lblSub_Delete.Click += new System.EventHandler(this.Table_Delete_Click);
            // 
            // pcSub_Delete
            // 
            this.pcSub_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pcSub_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcSub_Delete.Image = ((System.Drawing.Image)(resources.GetObject("pcSub_Delete.Image")));
            this.pcSub_Delete.Location = new System.Drawing.Point(188, 9);
            this.pcSub_Delete.Name = "pcSub_Delete";
            this.pcSub_Delete.Size = new System.Drawing.Size(20, 26);
            this.pcSub_Delete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcSub_Delete.TabIndex = 0;
            this.pcSub_Delete.TabStop = false;
            this.pcSub_Delete.Click += new System.EventHandler(this.Table_Delete_Click);
            // 
            // lblNoTables
            // 
            this.lblNoTables.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNoTables.AutoSize = true;
            this.lblNoTables.Font = new System.Drawing.Font("Segoe UI", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoTables.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblNoTables.Location = new System.Drawing.Point(390, 226);
            this.lblNoTables.Name = "lblNoTables";
            this.lblNoTables.Size = new System.Drawing.Size(196, 50);
            this.lblNoTables.TabIndex = 32;
            this.lblNoTables.Text = "No Tables";
            // 
            // lblNoRooms
            // 
            this.lblNoRooms.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblNoRooms.AutoSize = true;
            this.lblNoRooms.BackColor = System.Drawing.Color.Silver;
            this.lblNoRooms.Font = new System.Drawing.Font("Segoe UI", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoRooms.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblNoRooms.Location = new System.Drawing.Point(4, 253);
            this.lblNoRooms.Name = "lblNoRooms";
            this.lblNoRooms.Size = new System.Drawing.Size(199, 50);
            this.lblNoRooms.TabIndex = 33;
            this.lblNoRooms.Text = "No Rooms";
            // 
            // btnAdd_flpRoom
            // 
            this.btnAdd_flpRoom.Location = new System.Drawing.Point(3, 491);
            this.btnAdd_flpRoom.Name = "btnAdd_flpRoom";
            this.btnAdd_flpRoom.Size = new System.Drawing.Size(75, 23);
            this.btnAdd_flpRoom.TabIndex = 18;
            this.btnAdd_flpRoom.Text = "Add";
            this.btnAdd_flpRoom.UseVisualStyleBackColor = true;
            this.btnAdd_flpRoom.Click += new System.EventHandler(this.btnAdd_flpRoom_Click);
            // 
            // btnRemove_flpRoom
            // 
            this.btnRemove_flpRoom.Location = new System.Drawing.Point(126, 491);
            this.btnRemove_flpRoom.Name = "btnRemove_flpRoom";
            this.btnRemove_flpRoom.Size = new System.Drawing.Size(75, 23);
            this.btnRemove_flpRoom.TabIndex = 19;
            this.btnRemove_flpRoom.Text = "Remove";
            this.btnRemove_flpRoom.UseVisualStyleBackColor = true;
            this.btnRemove_flpRoom.Click += new System.EventHandler(this.btnRemove_flpRoom_Click);
            // 
            // frmTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(748, 549);
            this.Controls.Add(this.lblNoRooms);
            this.Controls.Add(this.lblNoTables);
            this.Controls.Add(this.pnlSub_Pannel);
            this.Controls.Add(this.flpTable);
            this.Controls.Add(this.pnlTable);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTable";
            this.Text = "Tables";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlTable.ResumeLayout(false);
            this.pnlTable.PerformLayout();
            this.flpRoom.ResumeLayout(false);
            this.pnlSub_Pannel.ResumeLayout(false);
            this.pnlSub_Pannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Info)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcSub_Delete)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTable;
        private System.Windows.Forms.Label lblTable;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.FlowLayoutPanel flpTable;
        private System.Windows.Forms.Button btnHideShow;
        private System.Windows.Forms.Panel pnlSub_Pannel;
        private System.Windows.Forms.Label lblSub_Name;
        private System.Windows.Forms.Label lblSub_Add;
        private System.Windows.Forms.PictureBox pcSub_Add;
        private System.Windows.Forms.Label lblSub_Delete;
        private System.Windows.Forms.PictureBox pcSub_Delete;
        private System.Windows.Forms.FlowLayoutPanel flpRoom;
        private System.Windows.Forms.Label lblNoTables;
        private System.Windows.Forms.Label lblNoRooms;
        private System.Windows.Forms.Label lblSub_Info;
        private System.Windows.Forms.PictureBox pcSub_Info;
        private System.Windows.Forms.Button btnRemove_flpRoom;
        private System.Windows.Forms.Button btnAdd_flpRoom;
    }
}