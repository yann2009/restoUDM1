﻿/************************************************************************
	Filename 	 :	ucTables.cs
	Created  	 :	29/10/2013
	Author   	 :	Hisham MAUDARBOCUS
	Description  :	Table usercontrol containing image and a label text
*************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using restoPOS.Commons;

namespace restoPOS.Forms.Sale.Table
{
    public partial class ucTables : UserControl
    {
        public event EventHandler TableClick;

        private string m_tableID;
        public string TableID
        {
            get { return m_tableID; }
            set { m_tableID = value; }
        }

        public string TableLabel
        {
            get { return lblTable.Text; }
            set { lblTable.Text = value; }
        }

        private Entities.TableStatus m_statusTable;
        public Entities.TableStatus StatusTable
        {
            get { return m_statusTable; }
            set
            {
                m_statusTable = value;

                if (((int)m_statusTable) == 0) // Vacant
                    lblTable.BackColor = Color.White;
                else if (((int)m_statusTable) == 1) // Occupied
                    lblTable.BackColor = Color.FromArgb(255, 224, 192);
                else // Pending
                    lblTable.BackColor = Color.FromArgb(255, 192, 192);
            }
        }

        public ucTables()
        {
            InitializeComponent();
        }

        private void Table_Click(object sender, EventArgs e)
        {
            TableClick(sender, e);
        }
    }
}
