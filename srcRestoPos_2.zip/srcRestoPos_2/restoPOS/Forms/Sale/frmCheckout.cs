﻿/*
 * Name         :  frmCheckout.cs
 * Programmer   :  Kawshik TONOO
 * Date         :  28/10/2013
 * Description  :  code for frmCheckout
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using restoPOS.Commons;

namespace restoPOS.Forms.Sale
{
    public partial class frmCheckout : Form
    {
        public frmCheckout()
        {
            InitializeComponent();

            ucNumKeypad1.NumKeypadKeyPressed += new Commons.UserControls.Keypads.ucNumKeypad.NumKeypadKeyPressedHandler(ucKeyPressed);
            ucNumKeypad1.ClearKeyPressed += new Commons.UserControls.Keypads.ucNumKeypad.ClearKeyPressedHandler(ucClearKeyPressed);
            
        }

        private void ucKeyPressed(string keyValue)
        {
            txtAmount.Text += keyValue;
        }

        private void ucClearKeyPressed()
        {
            txtAmount.Text = "1";
        }

        private void meClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void flPnlProduct_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void ucNumKeypad1_Load(object sender, EventArgs e)
        {
            ucNumKeypad1.GoButtonEnable = false;
        }

        private void frmCheckout_Load(object sender, EventArgs e)
        {
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void flPnlCategory_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lsItems_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            if (txtAmount.Text.Length > 0)
            {
                txtAmount.Text = txtAmount.Text.Substring(0, txtAmount.Text.Length - 1);
            }
            if (txtAmount.Text.Length == 0)
            {
                txtAmount.Text = "1";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double allPrice=0.0;
            foreach (double price in lbPrix.Items)
            {
                allPrice += price;

            }
            
            Forms.Sale.frmBill frmBl = new Forms.Sale.frmBill();
            frmBl.Show();
            frmBl.val = allPrice;
        }

        private void btnDrinks_Click(object sender, EventArgs e)
        {
            coke.Visible = true;
            sprite.Visible = true;
            gBeer.Visible = true;
            taco.Visible = false;
            vWrap.Visible = false;
            capp.Visible = false;
            latte.Visible = false;
               
            


        }

        private void btnSndwch_Click(object sender, EventArgs e)
        {
            coke.Visible = false;
            sprite.Visible = false;
            gBeer.Visible = false;
            taco.Visible = true;
            vWrap.Visible = true;
            capp.Visible = false;
            latte.Visible = false;
        }

        private void btnCoff_Click(object sender, EventArgs e)
        {
            coke.Visible = false;
            sprite.Visible = false;
            gBeer.Visible = false;
            taco.Visible = false;
            vWrap.Visible = false;
            capp.Visible = true;
            latte.Visible = true;
        }

        private void item_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            //lsItems.Items.Clear();
            lsItems.Items.Add(btn.Text );
            lbPrix.Items.Add (Convert.ToDouble(btn.Tag.ToString()) * Convert.ToDouble(txtAmount.Text));
        }
    }
}
